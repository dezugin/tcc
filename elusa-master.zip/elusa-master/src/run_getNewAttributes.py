import sys

def main():

    from us_election_collectors.getNewAttributes import getNewAttributes

    scriptNumber = sys.argv[1]

    totalScripts = sys.argv[2]

    totalDocuments = sys.argv[3]

    getNewAttributes.getNewAttributes(scriptNumber=scriptNumber, totalScripts=totalScripts, totalDocuments=totalDocuments)



if __name__ == '__main__':
    main()
