import sys

"""
Run the scripts election US
"""
def main():
    from twitter_data_collector.dataCollector import dataCollector

    track_list = ['#HeatherHeyer', 'Heather Heyer', '#resistance', '#WhiteSupremacist', "#WPWW", "#Conservative",
                  "#Redneck", "#BlackLivesMatter", "#NoHate", "#NoWhiteSupremacyHouse", "#NoRacism", "#Charlottesville",
                  "#NotMyPresident", "#WhiteLivesMatter", "#RacismInChief", "#TrumpsArmy", "#WhiteNationalists"]

    from pymongo import MongoClient

    # MongoDB connection
    client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
    #client = MongoClient('mongodb://localhost:27017/')
    client.usa_hate_discourse.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
    print('Connected to MongoDB!', flush=True)
    db = client.usa_hate_discourse
    print('Connected to usa_hate_discourse DB!', flush=True)

    scriptNumber = int(sys.argv[1])

    scriptToBeExecuted = int(sys.argv[2])

    usedTokens = int(sys.argv[3])

    if(scriptToBeExecuted == 1):
        dataCollector.getTweetsByFollowParameter(candidateIdsList=['25073877', '1339835893'], languagesList=['en'],
                                                 db=db, scriptNumber=scriptNumber, usedTokens=usedTokens)
    elif (scriptToBeExecuted == 2):
        totalTokens = sys.argv[4]
        #dataCollector.getTweetsByTrackParameter(trackList=track_list, languagesList=['en'], db=db,
        #                                        scriptNumber=scriptNumber, usedTokens=usedTokens,totalTokens=totalTokens)


    elif (scriptToBeExecuted == 3):
        followedCandidate = int(sys.argv[4])
        candidateName = ('realDonaldTrump' if (followedCandidate == 1) else 'HillaryClinton')
        dataCollector.getCandidateFollowers(followers_collection_name="candidates_followers", candidateName=candidateName,
                                            db=db, scriptNumber=scriptNumber, usedTokens=usedTokens)
    elif (scriptToBeExecuted == 4):
        totalTokens = sys.argv[4]
        dataCollector.getUsersTimeline(usersCollectionName='classified_users', tweetsCollectionName='tweets', scriptNumber=scriptNumber, db=db,
                                       totalTokens=totalTokens, usedTokens=usedTokens)
    elif (scriptToBeExecuted == 5):
        totalTokens = sys.argv[4]
        dataCollector.getUsersFriends(users_collection_name="users", relationships_collection_name="relationships",
                                      scriptNumber=scriptNumber, db=db, totalTokens=totalTokens, usedTokens=usedTokens,
                                      candidatesUsernameList=['realDonaldTrump', 'HillaryClinton'])
    elif (scriptToBeExecuted == 6):
        totalTokens = sys.argv[4]
        dataCollector.getUsersFollowers(users_collection_name="users", relationships_collection_name="relationships",
                                      scriptNumber=scriptNumber, db=db, totalTokens=totalTokens, usedTokens=usedTokens,
                                      candidatesUsernameList=['realDonaldTrump', 'HillaryClinton'])
    elif (scriptToBeExecuted == 7):
        totalTokens = sys.argv[4]
        dataCollector.getUsersTimeline(usersCollectionName='users', tweetsCollectionName='tweets',
                                       scriptNumber=scriptNumber, db=db,
                                       totalTokens=totalTokens, usedTokens=usedTokens)


if __name__ == '__main__':
    main()

