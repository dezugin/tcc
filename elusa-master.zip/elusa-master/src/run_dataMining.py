import sys

def main():
    from analysis.dataMining import dataMining

    # # Ask for the number and store it in userNumber
    # scenario = input('Enter 1 to First Scenario, 2 to Second Scenario and 3 to Third Scenario: ')
    # # Make sure the input is an integer number
    # scenario = int(scenario)
    #
    # if (scenario == 1):
    #     collection_name = 'timelines_only_eq_200_jan_nov_2016'
    #     folder_name = '1_First Scenario'
    #     feature_set_collection_name = 'features_set_gte_200_jan_nov_2016'
    # elif (scenario == 2):
    #     collection_name = "timelines_gte_200_jan_nov_2016"
    #     folder_name = '2_Second Scenario'
    #     feature_set_collection_name = 'features_set_gte_200_jan_nov_2016'
    # else:
    #     feature_set_collection_name = 'features_set_sampled_eq_200_jan_nov_2016'
    #     timelines_collection_name = "timelines_sampled_eq_200_jan_nov_2016"
    #     users_collections_names = ['features_set_sampled_eq_200_jan_nov_2016',
    #                                'users_politicalhashtags_sampled_eq_200_jan_nov_2016',
    #                                'users_influential_sampled_eq_200_jan_nov_2016']
    #
    #     timelines_collection_name = "timelines_sampled_eq_200_jan_nov_2016"
    #     users_collections_names = ['features_set_sampled_eq_200_jan_nov_2016',
    #                                'users_politicalhashtags_sampled_eq_200_jan_nov_2016',
    #                                'users_influential_sampled_eq_200_jan_nov_2016']
    #
    #     folder_name = '3_Third Scenario'

    feature_set_collection_name = 'features_set_sampled'
    timelines_collection_name = "timelines_sampled"
    users_collections_names = ['features_set_sampled',
                               'users_politicalhashtags_sampled',
                               'users_influential_sampled']

    from pymongo import MongoClient

    # MongoDB connection
    client = MongoClient('mongodb://localhost:27017/')
    # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
    client.france_election.authenticate('josemar', 'pucmg$elusa$2016')
    print('Connected to MongoDB!', flush=True)
    dbElusa = client.france_election
    print('Connected to elusa DB!', flush=True)

    # Uncomment the line bellow to build the hashtag cloud files
    csvs_names = ['bots_clustered.csv',
                 'regular_users_clustered.csv',
                  'advocates_trump_clustered.csv',
                  'advocates_hillary_clustered.csv' ]

    csvs_names = ['bots_clustered.csv', 'advocates_lepen_clustered.csv', 'advocates_macron_clustered.csv', 'regular_users_clustered.csv']

    # from threading import Thread
    # from datetime import datetime
    # import logging
    #
    # logging.basicConfig(level=logging.INFO,
    #                     format='(%(threadName)-10s) %(message)s', )
    #
    # start_time = datetime.now()
    #
    folder_name = ""
    #
    # threads = []
    # for csv_name in csvs_names:
    #     t = Thread(target=dataMining.setClustersLabelsOnDataCollections, args=(dbElusa,
    #                                                   timelines_collection_name,
    #                                                   users_collections_names,
    #                                                   folder_name, csv_name,))
    #     threads.append(t)
    #
    # # Start all threads
    # for x in threads:
    #     x.start()
    #
    # # Wait for all of them to finish
    # for x in threads:
    #     x.join()
    #
    # end_time = datetime.now()
    # print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
    #     start_time, end_time, (end_time - start_time).seconds))


    '''
    Only for tests
    '''
    politicalhashtags_collection_name ='users_politicalhashtags_sampled'
    dataMining.testRefineClustersLabelsOnDataCollections(dbElusa, timelines_collection_name=timelines_collection_name,
                                                             featuresset_collection_name=feature_set_collection_name,
                                                             politicalhashtags_collection_name=politicalhashtags_collection_name,
                                                            influentialusers_collection_name='users_influential_sampled',
                                                            users_collections_names=users_collections_names)

    #mood_variations_collections = ['mood_variations_and_inteferences', 'event_mood_variations_and_interferences']
    #dataMining.setClustersLabelsOnMoodVariationCollections(folder_name, feature_set_collection_name, mood_variations_collections)

    # dataMining.createClusteringResultsCSV(folder_name=folder_name, selected_features_set_csv_name="selected_features_data_rot_identified.csv",
    #                                                users_set_csv_name='users_refined_clusters.csv', merged_csv_name='users_clustered_results.csv')


    feature_set_collection_name = 'features_set_sampled'
    timelines_collection_name = "timelines_sampled"
    users_collections_names = ['features_set_sampled',
                               'users_politicalhashtags_sampled',
                               'users_influential_sampled']

    # dataMining.setPoliticalHashtagUsageAttributeOnUserCollection(featuresset_collection_name=feature_set_collection_name,
    #                                                              politicalhashtags_collection_name='users_politicalhashtags_sampled')

if __name__ == '__main__':
    main()
