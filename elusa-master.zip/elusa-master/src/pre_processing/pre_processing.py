#!/usr/bin/python
"""
Script to perform data mining.
Author: Josemar Caetano
Date: 05/31/17
"""

path_name = '/home/josemar/Desktop/research_france/R'

import os
import sys
import subprocess
from datetime import datetime
import time

import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import numpy as np

import pickle


class preProcessing:
    def __init__(self):
        pass

    def buildTimelinesSampledCollection(db):
        try:
           tweets = db.timelines_sampled_eq_200_jan_nov_2016.find({}, no_cursor_timeout=True)

           users = {}

           for tweet in tweets:
               if tweet['tweet']['user']['username'] in users:
                   users[tweet['tweet']['user']['username']] += 1
               else:
                   users[tweet['tweet']['user']['username']] = 1

               if users[tweet['tweet']['user']['username']] <= 200:
                   db.new_timelines_sampled_eq_200_jan_nov_2016.insert_one(tweet)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)