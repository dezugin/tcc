#!/usr/bin/python
"""
Script to get tweets of elections using Tweepy API.
Author: Josemar Caetano
Date: 04/25/17
"""

import os
import sys
from datetime import datetime
import time

import tweepy

from twitter_document_processing.tweetMethods import tweetMethods

from multiprocessing import Process
from threading import Thread
import subprocess

from requests.exceptions import Timeout, ConnectionError
from requests.packages.urllib3.exceptions import ReadTimeoutError

import threading
import time
import logging

logging.basicConfig(level=logging.INFO,
                    format='(%(threadName)-10s) %(message)s', )

class dataCollector():
    def __init__(self):
        pass

    def getInvalidUsers(users_collection_name, relationships_collection_name, scriptNumber, db, totalTokens, usedTokens, candidatesUsernameList):
        try:
            start_time = datetime.now()

            print('Executing getUsersFollowers with candidateName \tscriptNumber = ',
                  scriptNumber, flush=True)
            # Get access and key from another class
            auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

            # Create the Tweepy API service
            api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True, retry_count=100, retry_delay=10,
                             retry_errors=set([401, 404, 500, 503]))

            totalDocuments = db[users_collection_name].count({"$and":[{"class":{"$exists":True}},{"class":{"$ne":-1}}]})
            usersByScript = totalDocuments / int(totalTokens)
            usersByScript = int(usersByScript) + 1

            #referenceValueToSkip = ((int(scriptNumber) - int(referenceValueToSkip)) + 1)

            referenceValueToSkip = (int(scriptNumber)-1) * int(usersByScript)


            print("Total documents: ", totalDocuments, "\tUsers by script: ", usersByScript,
                  "\tSkip: ", referenceValueToSkip,flush=True)

            users = db[users_collection_name].find({"$and":[{"class":{"$exists":True}},{"class":{"$ne":-1}}]},no_cursor_timeout=True).skip(int(referenceValueToSkip)).limit(usersByScript)

            for source_user in users:
                test_bd = db['invalid_users_sampled'].find_one({"_id": source_user['_id']})
                if(test_bd is None):
                    try:
                        test = api.get_user(screen_name=source_user["_id"])
                    except Exception as e:
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                        logging.info(
                            '\nuser does not exist:  ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                                fname) + str(exc_tb.tb_lineno) +
                            '\tDatetime: ' + str(datetime.now()))
                        try:
                            db['invalid_users_sampled'].insert_one({"_id": source_user['_id']})
                        except Exception as e:
                            exc_type, exc_obj, exc_tb = sys.exc_info()
                            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                            logging.info(
                                '\nInvalid user already inserted: ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                                    fname) + str(exc_tb.tb_lineno) +
                                '\tDatetime: ' + str(datetime.now()))
        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            logging.info(
                '\nError: ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                    fname) + str(exc_tb.tb_lineno) +
                '\tDatetime: ' + str(datetime.now()))

        end_time = datetime.now()
        print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
            start_time, end_time, (end_time - start_time).seconds))

        print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)

    def getUsersNetwork(users_collection_name, relationships_collection_name, scriptNumber, db, totalTokens, usedTokens, candidatesUsernameList):
        try:
            start_time = datetime.now()

            print('Executing getUsersFollowers with candidateName \tscriptNumber = ',
                  scriptNumber, flush=True)
            # Get access and key from another class
            auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

            # Create the Tweepy API service
            api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True, retry_count=100, retry_delay=10,
                             retry_errors=set([401, 404, 500, 503]))

            totalDocuments = db[users_collection_name].count({"$and":[{"class":{"$exists":True}},{"class":{"$ne":-1}}]})
            usersByScript = totalDocuments / int(totalTokens)
            usersByScript = int(usersByScript) + 1

            #referenceValueToSkip = ((int(scriptNumber) - int(referenceValueToSkip)) + 1)

            referenceValueToSkip = (int(scriptNumber)-1) * int(usersByScript)


            print("Total documents: ", totalDocuments, "\tUsers by script: ", usersByScript,
                  "\tSkip: ", referenceValueToSkip,flush=True)

            users = db[users_collection_name].find({"$and":[{"class":{"$exists":True}},{"class":{"$ne":-1}}]},no_cursor_timeout=True).skip(int(referenceValueToSkip)).limit(usersByScript)

            all_users = db[users_collection_name].find({"$and":[{"class":{"$exists":True}},{"class":{"$ne":-1}}]},no_cursor_timeout=True)

            for source_user in users:
                    test_bd = db['invalid_users_sampled'].find_one({"_id": source_user['_id']})
                    if(test_bd is None):
                        try:
                            #test = api.get_user(screen_name=source_user["_id"])
                            for target_user in all_users:
                                test2_bd = db['invalid_users_sampled'].find_one({"_id": target_user['_id']})
                                if (test2_bd is None):
                                    try:
                                        relation = api.show_friendship(source_screen_name=source_user["_id"],
                                                                       target_screen_name=target_user['_id'])
                                        if relation[0].following is True:
                                            relationshipDocument = tweetMethods.createRelationshipDocument(follower=str(source_user['_id']),
                                                                                                           followed=str(target_user['_id']))
                                            try:
                                                db[relationships_collection_name].insert_one(relationshipDocument)
                                            except Exception as e:
                                                exc_type, exc_obj, exc_tb = sys.exc_info()
                                                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                                                logging.info(
                                                    '\nrelationship already inserted: ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                                                        fname) + str(exc_tb.tb_lineno) +
                                                    '\tDatetime: ' + str(datetime.now()))
                                        if relation[1].following is True:
                                            relationshipDocument = tweetMethods.createRelationshipDocument(follower=str(target_user['_id']),
                                                                                                           followed=str(source_user['_id']))
                                            try:
                                                db[relationships_collection_name].insert_one(relationshipDocument)
                                            except Exception as e:
                                                exc_type, exc_obj, exc_tb = sys.exc_info()
                                                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                                                logging.info(
                                                    '\nrelationship already inserted: ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                                                        fname) + str(exc_tb.tb_lineno) +
                                                    '\tDatetime: ' + str(datetime.now()))
                                    except Exception as e:
                                        exc_type, exc_obj, exc_tb = sys.exc_info()
                                        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                                        logging.info(
                                            '\nTarget user does not exist:  ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                                                fname) + str(exc_tb.tb_lineno) +
                                            '\tDatetime: ' + str(datetime.now()))
                                        try:
                                            db['invalid_users_sampled'].insert_one({"_id": target_user['_id']})
                                        except Exception as e:
                                            exc_type, exc_obj, exc_tb = sys.exc_info()
                                            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                                            logging.info(
                                                '\nInvalid user already inserted: ' + str(e) + '\tDetails: ' + str(
                                                    exc_type) + str(
                                                    fname) + str(exc_tb.tb_lineno) +
                                                '\tDatetime: ' + str(datetime.now()))
                            try:
                                db['building_network'].insert_one({"_id":source_user['_id']})
                            except Exception as e:
                                pass
                        except Exception as e:
                            exc_type, exc_obj, exc_tb = sys.exc_info()
                            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                            logging.info(
                                '\nSource user does not exist: ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                                    fname) + str(exc_tb.tb_lineno) +
                                '\tDatetime: ' + str(datetime.now()))
                            try:
                                db['invalid_users_sampled'].insert_one({"_id": source_user['_id']})
                            except Exception as e:
                                exc_type, exc_obj, exc_tb = sys.exc_info()
                                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                                logging.info(
                                    '\nInvalid user already inserted: ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                                        fname) + str(exc_tb.tb_lineno) +
                                    '\tDatetime: ' + str(datetime.now()))

            end_time = datetime.now()
            print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds))

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    """
    Function that obtains the parameters of the followers of the candidates
        :param usedTokens:
    """
    def getAuthAssociatedWithScript(scriptNumber, usedTokens):
        auth = None

        try:
            scriptNumber = int(scriptNumber)
            scriptNumber = scriptNumber + int(usedTokens)
            print('Executing getAuthAssociatedWithScript with scriptNumber = ', scriptNumber, flush=True)

            mod = __import__('configuration.authentication', fromlist=['authentication_' + str(scriptNumber)])
            auth = getattr(mod, 'authentication_' + str(scriptNumber))()

            consumer_key = auth.getconsumer_key()
            consumer_secret = auth.getconsumer_secret()
            access_token = auth.getaccess_token()
            access_token_secret = auth.getaccess_token_secret()

            # Authentication
            auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
            auth.secure = True
            auth.set_access_token(access_token, access_token_secret)

            return (auth)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('External exception error: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, flush=True)

    """
    Function getting the followers tweets parameters
        :param languagesList:
        :param db:
        :param scriptNumber:
        :param usedTokens:
    """
    def getTweetsByFollowParameter(candidateIdsList, languagesList, db, scriptNumber, usedTokens):
       try:
           print('Executing getTweetsByFollowParameter with scriptNumber = ', scriptNumber, flush=True)
           # Get access and key from another class
           auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

           # Control variable to store the amount of collected tweets
           collectedTweets = 0
           # Create the Tweepy API service
           api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=False, retry_count=100, retry_delay=10,
                            retry_errors=set([401, 404, 500, 503]))

           streamListener = twitterStreamListener(api, collectedTweets, db)
           # Establishes the authentication info, the service and the filter
           myStream = tweepy.Stream(auth=api.auth, listener=streamListener)
           # Follow tweets of Marine Le Pen and Emmanuel Macron
           myStream.filter(follow=candidateIdsList, languages=languagesList, async=True)

       except Exception as e:
           exc_type, exc_obj, exc_tb = sys.exc_info()
           fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
           print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                 datetime.now(), flush=True)

    """
    Function to get tweets parameters
        :param languagesList:
        :param db:
        :param scriptNumber:
        :param usedTokens:
    """
    def getTweetsByTrackParameter(tweetsCollectionName, trackList, languagesList, db, scriptNumber, usedTokens):
        try:
           from twitter_data_collector.tweetsByTrackParameter import tweetsByTrackParameter

           tweetsByTrackParameter.startCollecting(tweetsCollectionName=tweetsCollectionName, trackList=trackList,
                                                  languagesList=languagesList, db=db, scriptNumber=scriptNumber,
                                                  usedTokens=usedTokens)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
            datetime.now(), flush=True)

    """
    Function to handle errors
    """
    def handle_errors(cursor):
        while True:
            try:
                yield cursor.next()
            except tweepy.TweepError:
                time.sleep(20 * 60)

    """
    Function to get followers of the candidates
        :param db:
        :param scriptNumber:
        :param usedTokens:
    """
    def getCandidateFollowers(followers_collection_name, candidateName, db, scriptNumber, usedTokens):
       try:
           print('Executing getCandidateFollowers with candidateName = ', candidateName,'\tscriptNumber = ', scriptNumber, flush=True)
           # Get access and key from another class
           auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

           # Create the Tweepy API service
           api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=False, retry_count=100, retry_delay=10,
                            retry_errors=set([401, 404, 500, 503]))

           totalUsers = 0
           for user in dataCollector.handle_errors(tweepy.Cursor(api.followers, screen_name=str(candidateName)).items()):
               #print(user)
               userDocument = tweetMethods.createFollowerDocument(user, str(candidateName))
               try:
                    db[followers_collection_name].insert_one(userDocument)
                    totalUsers+=1
                    if (totalUsers % 1000) == 0:
                        print(totalUsers, " inserted so far")
               except Exception as e:
                   exc_type, exc_obj, exc_tb = sys.exc_info()
                   fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                   print('\ntweet already inserted: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno,
                         '\tDatetime: ',
                         datetime.now(), flush=True)


       except Exception as e:
           exc_type, exc_obj, exc_tb = sys.exc_info()
           fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
           print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                 datetime.now(), flush=True)

    """
    Function that defines the types of users
        :param db:
        :param referenceValueToSkip:
        :param totalTokens:
        :param usedTokens:
    """
    def getUsersTimeline(usersCollectionName, tweetsCollectionName, scriptNumber, db, totalTokens, usedTokens):
        try:
            print('Executing getUsersTimeline with totalScripts = ', totalTokens, '\tscriptNumber = ',
                  scriptNumber,'\tusedTokens= ',usedTokens, flush=True)
            start_time = datetime.now()

            # Get access and key from another class
            auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

            api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=False, retry_count=100, retry_delay=10,
                             retry_errors=set([401, 404, 500, 503]))

            totalDocuments = db[usersCollectionName].count({})
            usersByScript = totalDocuments / int(totalTokens)
            usersByScript = int(usersByScript) + 1

            referenceValueToSkip = (int(scriptNumber) - 1) * int(usersByScript)

            print("Total documents: ", totalDocuments, "\tUsers by script: ", usersByScript,
                  "\tSkip: ", referenceValueToSkip, flush=True)

            # Global variables
            total_tweets = 0
            total_retweets = 0
            users_total = 0

            users = db[usersCollectionName].find({},no_cursor_timeout=True).skip(int(referenceValueToSkip)).limit(usersByScript)

            for user in users:
                if user["timeline_collected"] is False:
                    # Insert user in dictionary only if at least one of the primary characteristics is true
                    valid_user = True
                    tweepyError = False
                    try:
                        print("\n\tGetting timeline 200 last tweets from @", user['_id'], flush=True)
                        user_tweets = api.user_timeline(screen_name=user['_id'], count=200)
                    except tweepy.TweepError as ex:
                        print("Tweepy error: ", ex, flush=True)
                        tweepyError = True
                        if(ex.api_code == 34):
                            valid_user = False
                            print("\n\tUser @", user['_id'], " is NOT valid anymore.", flush=True)



                    if (tweepyError is False and valid_user is True):
                        users_total += 1
                        for raw_tweet in user_tweets:
                            tweet = tweetMethods.createTweetDocument(r_tweet=raw_tweet, fromStreaming=False,
                                                                     originalTweet=False)
                            try:
                                db[tweetsCollectionName].insert_one(tweet)
                                if ('retweet' in tweet):
                                    # print("\n\t\tA new retweet was inserted!", flush=True)
                                    total_retweets += 1
                                else:
                                    # print("\n\t\tA new tweet was inserted!", flush=True)
                                    total_tweets += 1

                            except Exception as e:
                                exc_type, exc_obj, exc_tb = sys.exc_info()
                                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                                print('\ntweet already inserted: ', e, '\tDetails: ', exc_type, fname,
                                      exc_tb.tb_lineno,
                                      '\tDatetime: ', datetime.now(), flush=True)

                    # Update the DB
                    db[usersCollectionName].update_one({"_id": user['_id']},
                                        {"$set": {"timeline_collected": (tweepyError is False), "valid_user": valid_user}})

            # Write results and dictionaries on files
            print("\nTotal tweets: %d\nTotal retweets: %d\nTotal Valid Non-Advocates: %d" % (
                total_tweets, total_retweets, users_total))


            end_time = datetime.now()
            print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds))

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def getUsersFriends(users_collection_name, relationships_collection_name, scriptNumber, db, totalTokens,
                          usedTokens, candidatesUsernameList):
        try:
            start_time = datetime.now()

            print('Executing getUsersFriends with candidateName \tscriptNumber = ',
                  scriptNumber, flush=True)
            # Get access and key from another class
            auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

            # Create the Tweepy API service
            api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True, retry_count=100,
                             retry_delay=10,
                             retry_errors=set([401, 404, 500, 503]))

            # totalDocuments = db.users.count({'$and': [{"valid_user": True}, {'hop': 0}]})
            totalDocuments = db[users_collection_name].count({"$and":[{"class":{"$exists":True}},{"class":{"$ne":-1}}]})
            usersByScript = totalDocuments / int(totalTokens)
            usersByScript = int(usersByScript) + 1

            # referenceValueToSkip = ((int(scriptNumber) - int(referenceValueToSkip)) + 1)

            referenceValueToSkip = (int(scriptNumber) - 1) * int(usersByScript)

            print("Total documents: ", totalDocuments, "\tUsers by script: ", usersByScript,
                  "\tSkip: ", referenceValueToSkip, flush=True)

            users = db[users_collection_name].find({"$and":[{"class":{"$exists":True}},{"class":{"$ne":-1}}]},
                                                   no_cursor_timeout=True) \
                .skip(int(referenceValueToSkip)).limit(usersByScript)

            users_total_request = 0
            threads = []
            for user in users:
                if (user['control']['friends_collected'] is False and user['_id'] not in candidatesUsernameList):
                    dataCollector.getUserFriendsFromAPIAndPersistThem(users_collection_name=users_collection_name,
                                                                      relationships_collection_name=relationships_collection_name,
                                                                      api=api, db=db, user=user)
                #     # print(user['_id'], flush=True)
                #     t = Thread(target=dataCollector.getUserFriendsFromAPIAndPersistThem, args=(users_collection_name,
                #                                                                                  relationships_collection_name,
                #                                                                                  api, db, user,))
                #     # if (users_total_request == 0):
                #     #     start_time_request = datetime.now()
                #     threads.append(t)
                #     users_total_request += 1
                #
                # if (users_total_request == 15):
                #     print("15 users will be processed", flush=True)
                #     # Start all threads
                #     for x in threads:
                #         x.start()
                #
                #     # Wait for all of them to finish
                #     for x in threads:
                #         x.join()
                #
                #     # end_time_request = datetime.now()
                #     #
                #     # length_time_request = (end_time_request - start_time_request).seconds
                #     # seconds_to_sleep = (15 * 60) - length_time_request
                #
                #     # if (seconds_to_sleep > 0):
                #     #     print("sleeping for ", seconds_to_sleep / 60, " minutes", flush=True)
                #     #     time.sleep(seconds_to_sleep)  # Sleeps up to 15 minutes
                #
                #     users_total_request = 0
                #     threads = []

            end_time = datetime.now()
            print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds))

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def getUserFriendsFromAPIAndPersistThem(users_collection_name, relationships_collection_name, api, db, user):
        try:
            logging.info("\tGetting friends from @"+user['_id'])
            # Insert user in dictionary only if at least one of the primary characteristics is true
            valid_user = True
            tweepyError = False
            totalFriends = 0

            try:
                for friend in dataCollector.handle_errors(
                        tweepy.Cursor(api.friends_ids, screen_name=str(user['_id'])).items()):
                    # print(user)

                    friend = api.get_user(friend)
                    relationshipDocument = tweetMethods.createRelationshipDocument(follower=str(user['_id']),
                                                                                   followed=getattr(friend,'screen_name'))
                    try:
                        db[relationships_collection_name].insert_one(relationshipDocument)
                    except Exception as e:
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                        logging.info('\nrelationship already inserted: '+str(e)+'\tDetails: '+str(exc_type)+str(fname)+str(exc_tb.tb_lineno)+
                              '\tDatetime: '+str(datetime.now()))
                    totalFriends += 1
                    if (totalFriends % 1000) == 0:
                        logging.info(str(totalFriends)+" friends inserted so far")
                    try:
                        userDocument = tweetMethods.createUserDocument(username=getattr(friend, 'screen_name'),
                                                                       timelineCollected=False, hop=1)
                        db[users_collection_name].insert_one(userDocument)
                    except Exception as e:
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                        logging.info(
                            '\nuser already inserted: ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                                fname) + str(exc_tb.tb_lineno) +
                            '\tDatetime: ' + str(datetime.now()))
            except tweepy.TweepError as ex:
                logging.info("Tweepy error: "+str(ex))
                tweepyError = True
                if (ex.api_code == 34):
                    valid_user = False
                    logging.info("\tUser @" + user['_id'] + " is NOT valid anymore.")

            # Update the DB
            db[users_collection_name].update_one({"_id": user['_id']},
                                               {"$set": {"timeline_collected": (tweepyError is False),
                                                         "valid_user": valid_user}})

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            logging.info(
                '\nError: ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                    fname) + str(exc_tb.tb_lineno) +
                '\tDatetime: ' + str(datetime.now()))

    def getUsersFollowers(users_collection_name, relationships_collection_name, scriptNumber, db, totalTokens, usedTokens, candidatesUsernameList):
        try:
            start_time = datetime.now()

            print('Executing getUsersFollowers with candidateName \tscriptNumber = ',
                  scriptNumber, flush=True)
            # Get access and key from another class
            auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

            # Create the Tweepy API service
            api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True, retry_count=100, retry_delay=10,
                             retry_errors=set([401, 404, 500, 503]))

            #totalDocuments = db.users.count({'$and': [{"valid_user": True}, {'hop': 0}]})
            totalDocuments = db[users_collection_name].count({"$and":[{"class":{"$exists":True}},{"class":{"$ne":-1}}]})
            usersByScript = totalDocuments / int(totalTokens)
            usersByScript = int(usersByScript) + 1

            #referenceValueToSkip = ((int(scriptNumber) - int(referenceValueToSkip)) + 1)

            referenceValueToSkip = (int(scriptNumber)-1) * int(usersByScript)


            print("Total documents: ", totalDocuments, "\tUsers by script: ", usersByScript,
                  "\tSkip: ", referenceValueToSkip,flush=True)

            users = db[users_collection_name].find({"$and":[{"class":{"$exists":True}},{"class":{"$ne":-1}}]},
                                  no_cursor_timeout=True) \
                .skip(int(referenceValueToSkip)).limit(usersByScript)

            users_total_request = 0
            threads = []
            for user in users:
                if (user['control']['followers_collected'] is False and user['_id'] not in candidatesUsernameList):
                    dataCollector.getUserFollowersFromAPIAndPersistThem(users_collection_name=users_collection_name,
                                                                      relationships_collection_name=relationships_collection_name,
                                                                      api=api, db=db, user=user)
                #     #print(user['_id'], flush=True)
                #     t = Thread(target=dataCollector.getUserFollowersFromAPIAndPersistThem, args=(users_collection_name,
                #                                                                                relationships_collection_name,
                #                                                                                api, db, user, ))
                #     # if (users_total_request == 0):
                #     #     start_time_request = datetime.now()
                #     threads.append(t)
                #     users_total_request += 1
                #
                # if (users_total_request == 15):
                #     print("15 users will be processed", flush=True)
                #     # Start all threads
                #     for x in threads:
                #         x.start()
                #
                #     # Wait for all of them to finish
                #     for x in threads:
                #         x.join()
                #
                #     # end_time_request = datetime.now()
                #     #
                #     # length_time_request = (end_time_request - start_time_request).seconds
                #     # seconds_to_sleep = (15 * 60) - length_time_request
                #     #
                #     # if (seconds_to_sleep > 0):
                #     #     print("sleeping for ", seconds_to_sleep / 60, " minutes", flush=True)
                #     #     time.sleep(seconds_to_sleep)  # Sleeps up to 15 minutes
                #
                #     users_total_request = 0
                #     threads = []

            end_time = datetime.now()
            print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds))

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def getUserFollowersFromAPIAndPersistThem(users_collection_name, relationships_collection_name, api, db, user):
        try:
            logging.info("\tGetting followers from @"+user['_id'])
            # Insert user in dictionary only if at least one of the primary characteristics is true
            valid_user = True
            tweepyError = False
            totalFollowers = 0

            try:
                for follower in dataCollector.handle_errors(
                        tweepy.Cursor(api.followers_ids, screen_name=str(user['_id'])).items()):
                    # print(user)
                    relationshipDocument = tweetMethods.createRelationshipDocument(follower=str(user['_id']),
                                                                                   followed=getattr(follower,'screen_name'))
                    try:
                        db[relationships_collection_name].insert_one(relationshipDocument)
                    except Exception as e:
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                        logging.info('\nrelationship already inserted: '+str(e)+'\tDetails: '+str(exc_type)+str(fname)+str(exc_tb.tb_lineno)+
                              '\tDatetime: '+str(datetime.now()))
                    totalFollowers += 1
                    if (totalFollowers % 1000) == 0:
                        logging.info(str(totalFollowers)+" followers inserted so far")
                    try:
                        userDocument = tweetMethods.createUserDocument(username=getattr(follower, 'screen_name'),
                                                                       timelineCollected=False, hop=1)
                        db[users_collection_name].insert_one(userDocument)
                    except Exception as e:
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                        logging.info(
                            '\nuser already inserted: ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                                fname) + str(exc_tb.tb_lineno) +
                            '\tDatetime: ' + str(datetime.now()))
            except tweepy.TweepError as ex:
                logging.info("Tweepy error: "+str(ex))
                tweepyError = True
                if (ex.api_code == 34):
                    valid_user = False
                    logging.info("\tUser @" + user['_id'] + " is NOT valid anymore.")

            # Update the DB
            db[users_collection_name].update_one({"_id": user['_id']},
                                               {"$set": {"timeline_collected": (tweepyError is False),
                                                         "valid_user": valid_user}})

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            logging.info(
                '\nError: ' + str(e) + '\tDetails: ' + str(exc_type) + str(
                    fname) + str(exc_tb.tb_lineno) +
                '\tDatetime: ' + str(datetime.now()))


    def getFirstHopUsersFriends(scriptNumber, db, totalTokens, usedTokens, candidatesUsernameList):
        try:
            print('Executing getUsersFriends with candidateName \tscriptNumber = ',
                  scriptNumber, flush=True)
            # Get access and key from another class
            auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

            # Create the Tweepy API service
            api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=False, retry_count=100,
                             retry_delay=10,
                             retry_errors=set([401, 404, 500, 503]))

            totalDocuments = db.users.count({'$and': [{"valid_user": True}, {'hop': 1}]})
            usersByScript = totalDocuments / int(totalTokens)
            usersByScript = int(usersByScript) + 1

            referenceValueToSkip = (int(scriptNumber) - 1) * int(usersByScript)

            print("Total documents: ", totalDocuments, "\tUsers by script: ", usersByScript,
                  "\tSkip: ", referenceValueToSkip,flush=True)

            totalUsers = 0
            totalFriends = 0
            # Get all users from db
            users = db.users.find({'$and':[{'valid_user': True}, {'hop':1}]},
                                                no_cursor_timeout=True)\
                .skip(int(referenceValueToSkip)).limit(usersByScript)

            for user in users:
                if (user['friends_collected'] is False and user['_id'] not in candidatesUsernameList):
                    # Insert user in dictionary only if at least one of the primary characteristics is true
                    valid_user = True

                    try:
                        for friend in dataCollector.handle_errors(
                                tweepy.Cursor(api.friends, screen_name=str(user['_id'])).items()):
                            # print(user)
                            relationshipDocument = tweetMethods.createRelationshipDocument(follower=str(user['_id']),
                                                                                           followed=getattr(friend, 'screen_name')
                                                                                           )
                            try:
                                db.relationships.insert_one(relationshipDocument)
                            except Exception as e:
                                exc_type, exc_obj, exc_tb = sys.exc_info()
                                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                                print('\nrelationship already inserted: ', e, '\tDetails: ', exc_type, fname,
                                      exc_tb.tb_lineno,
                                      '\tDatetime: ', datetime.now(), flush=True)
                            totalFriends += 1
                            if (totalFriends % 1000) == 0:
                                print(totalFriends, " friends inserted so far")
                            try:
                                userDocument = tweetMethods.createUserDocument(username=getattr(friend, 'screen_name'),
                                                                               timelineCollected=False, hop=2)
                                db.users.insert_one(userDocument)
                            except Exception as e:
                                exc_type, exc_obj, exc_tb = sys.exc_info()
                                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                                print('\nuser already inserted: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno,
                                      '\tDatetime: ', datetime.now(), flush=True)
                    except tweepy.TweepError as ex:
                        # if(ex.api_code == 34):
                        valid_user = False

                    if (valid_user == True):
                        totalUsers +=1
                        # Update user in collection of analysed users
                        db.users.update_one({"_id": {'$eq':str(user['_id'])}},
                                                     {"$set": {"friends_collected": True}})

                    else:
                        print("\n\tUser @", user['_id'], " is NOT valid anymore.", flush=True)
                        # Update user in collection of analysed users
                        db.users.update_one({"_id": {'$eq':str(user['_id'])}},
                                                     {"$set": {"valid_user": False}})
                if (totalUsers % 1000) == 0:
                    print(totalUsers, " users' friends fetched so far")



        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def getFirstHopUsersFollowers(scriptNumber, db, totalTokens, usedTokens, candidatesUsernameList):
        try:
            print('Executing getUsersFollowers with candidateName \tscriptNumber = ',
                  scriptNumber, flush=True)
            # Get access and key from another class
            auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

            # Create the Tweepy API service
            api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=False, retry_count=100,
                             retry_delay=10,
                             retry_errors=set([401, 404, 500, 503]))

            totalDocuments = db.users.count({'$and': [{"valid_user": True}, {'hop': 1}]})
            usersByScript = totalDocuments / int(totalTokens)
            usersByScript = int(usersByScript) + 1

            referenceValueToSkip = (int(scriptNumber) - 1) * int(usersByScript)

            print("Total documents: ", totalDocuments, "\tUsers by script: ", usersByScript,
                  "\tSkip: ", referenceValueToSkip, flush=True)

            totalUsers = 0
            totalFollowers = 0
            # Get all users from db
            users = db.users.find({'$and': [{'valid_user': True}, {'hop': 1}]},
                                  no_cursor_timeout=True) \
                .skip(int(referenceValueToSkip)).limit(usersByScript)

            for user in users:
                if (user['followers_collected'] is False and user['_id'] not in candidatesUsernameList):
                    # Insert user in dictionary only if at least one of the primary characteristics is true
                    valid_user = True

                    try:
                        for follower in dataCollector.handle_errors(
                                tweepy.Cursor(api.followers, screen_name=str(user['_id'])).items()):
                            # print(user)
                            relationshipDocument = tweetMethods.createRelationshipDocument(follower=str(user['_id']),
                                                                                           followed=getattr(follower,
                                                                                                            'screen_name')
                                                                                           )
                            try:
                                db.relationships.insert_one(relationshipDocument)
                            except Exception as e:
                                exc_type, exc_obj, exc_tb = sys.exc_info()
                                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                                print('\nrelationship already inserted: ', e, '\tDetails: ', exc_type, fname,
                                      exc_tb.tb_lineno,
                                      '\tDatetime: ', datetime.now(), flush=True)
                            totalFollowers += 1
                            if (totalFollowers % 1000) == 0:
                                print(totalFollowers, " followers inserted so far")

                            try:
                                userDocument = tweetMethods.createUserDocument(
                                    username=getattr(follower, 'screen_name'),
                                    timelineCollected=False, hop=2)
                                db.users.insert_one(userDocument)
                            except Exception as e:
                                exc_type, exc_obj, exc_tb = sys.exc_info()
                                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                                print('\nuser already inserted: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno,
                                      '\tDatetime: ', datetime.now(), flush=True)
                    except tweepy.TweepError as ex:
                        # if(ex.api_code == 34):
                        valid_user = False

                    if (valid_user == True):
                        totalUsers += 1
                        # Update user in collection of analysed users
                        db.users.update_one({"_id": {'$eq': str(user['_id'])}},
                                            {"$set": {"followers_collected": True}})

                    else:
                        print("\n\tUser @", user['_id'], " is NOT valid anymore.", flush=True)
                        # Update user in collection of analysed users
                        db.users.update_one({"_id": {'$eq': str(user['_id'])}},
                                            {"$set": {"valid_user": False}})
                if (totalUsers % 1000) == 0:
                    print(totalUsers, " users' followers fetched so far")



        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)


    """
    Function that defines the types of users
            :param db:
            :param referenceValueToSkip:
            :param totalTokens:
            :param usedTokens:
    """

    def getFirstHopUsersTimeline(scriptNumber, db, totalTokens, usedTokens):
        try:
            print('Executing getCandidateFollowers with totalScripts = ', totalTokens, '\tscriptNumber = ',
                  scriptNumber, flush=True)
            start_time = datetime.now()

            # Get access and key from another class
            auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

            api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=False, retry_count=100,
                             retry_delay=10,
                             retry_errors=set([401, 404, 500, 503]))

            # Global variables
            total_tweets = 0
            total_retweets = 0
            users_total = 0

            totalDocuments = db.users.count({'$and':[{"valid_user": True},{'hop':1}]})
            usersByScript = totalDocuments / int(totalTokens)
            usersByScript = int(usersByScript) + 1

            referenceValueToSkip = (int(scriptNumber) - 1) * int(usersByScript)

            print("Total documents: ", totalDocuments, "\tUsers by script: ", usersByScript,
                  "\tSkip: ", referenceValueToSkip, flush=True)

            users = db.users.find(
                {'$and': [{"valid_user": True}, {"hop":1}]},
                no_cursor_timeout=True).skip(int(referenceValueToSkip)).limit(usersByScript)

            for user in users:
                if (user['timeline_collected'] is False):
                    # Insert user in dictionary only if at least one of the primary characteristics is true
                    valid_user = True
                    try:
                        print("\n\tGetting timeline 200 last tweets from @", user['_id'], flush=True)
                        user_tweets = api.user_timeline(screen_name=user['_id'], count=200)
                    except tweepy.TweepError as ex:
                        # if(ex.api_code == 34):
                        valid_user = False

                    if (valid_user == True):
                        users_total += 1
                        for raw_tweet in user_tweets:
                            tweet = tweetMethods.createTweetDocument(r_tweet=raw_tweet, fromStreaming=False,
                                                                     originalTweet=False)
                            try:
                                db.tweets.insert_one(tweet)

                                if (tweet['retweet'] is True):
                                    # print("\n\t\tA new retweet was inserted!", flush=True)
                                    total_retweets += 1
                                else:
                                    # print("\n\t\tA new tweet was inserted!", flush=True)
                                    total_tweets += 1

                            except Exception as e:
                                print('\ntweet already inserted: ', flush=True)
                    else:
                        print("\n\tUser @", user['_id'], " is NOT valid anymore.", flush=True)

                    # Update the DB
                    db.users.update_one({"_id": user['_id']},
                                            {"$set": {"timeline_collected": valid_user, "valid_user": valid_user}})

            # Write results and dictionaries on files
            print("\nTotal tweets: %d\nTotal retweets: %d\nTotal Users: %d" % (
                total_tweets, total_retweets, users_total))

            end_time = datetime.now()
            print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds))

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def setBotOrNotScoreOnClassifiedUsers(db, classified_users_collection, users_collection):
        try:
            print('Setting existing botornot score on classified users', flush=True)
            start_time = datetime.now()

            users = db[classified_users_collection].find({},no_cursor_timeout=True)

            for user in users:
                document = db[users_collection].find_one({"_id":user['_id']})
                botornotscore = -1
                try:
                    botornotscore = document['user']['bot_or_not_score']
                except Exception as e:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                    print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                          datetime.now(),
                          flush=True)

                db[classified_users_collection].update_one({"_id":user['_id']}, {"$set":{"bot_or_not_score":botornotscore}})

            end_time = datetime.now()
            print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds))

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def getUsersBotOrNotScore(usersCollectionName, scriptNumber, db, totalTokens, usedTokens):
        try:
            print('Executing getUsersBotOrNotScore with totalScripts = ', totalTokens, '\tscriptNumber = ',
                  scriptNumber,'\tusedTokens= ',usedTokens, flush=True)
            start_time = datetime.now()

            try:
                import urllib.request as urllib2
            except ImportError:
                import urllib2

            import botometer

            # Get access and key from another class
            mod = __import__('configuration.authentication', fromlist=['authentication_' + str(scriptNumber)])
            auth = getattr(mod, 'authentication_' + str(scriptNumber))()

            consumer_key = auth.getconsumer_key()
            consumer_secret = auth.getconsumer_secret()
            access_token = auth.getaccess_token()
            access_token_secret = auth.getaccess_token_secret()

            mashape_key = "PEqZDZKZhQmshLNBkg5M8hZpsNJGp1HGd3Ejsn3sltP23YFRX3"
            twitter_app_auth = {
                'consumer_key': consumer_key,
                'consumer_secret': consumer_secret,
                'access_token': access_token,
                'access_token_secret': access_token_secret,
            }
            bom = botometer.Botometer(mashape_key=mashape_key, **twitter_app_auth)


            totalDocuments = db[usersCollectionName].count({})
            usersByScript = totalDocuments / int(totalTokens)
            usersByScript = int(usersByScript) + 1

            referenceValueToSkip = (int(scriptNumber) - 1) * int(usersByScript)

            print("Total documents: ", totalDocuments, "\tUsers by script: ", usersByScript,
                  "\tSkip: ", referenceValueToSkip, flush=True)

            # Global variables
            users_total = 0

            users = db[usersCollectionName].find({},no_cursor_timeout=True).skip(int(referenceValueToSkip)).limit(usersByScript)

            start_time_request = datetime.now()
            for user in users:
                if user["bot_or_not_score"] == -1 and user['control']['valid_user'] is True:
                    # Insert user in dictionary only if at least one of the primary characteristics is true
                    valid_user = True
                    botometer_error = False
                    error_description = None
                    bot_score = -1
                    try:
                        try:
                            print("\n\tGetting BotOrNotScore from @", user['_id'], flush=True)
                            result = bom.check_account(user['_id'])
                            bot_score = result['scores']['universal']
                        except urllib2.HTTPError as err:
                            error_description = str(err)
                            if err.code == 500:
                                print("HTTP error: ", err, flush=True)
                                botometer_error = True

                                end_time_request = datetime.now()

                                length_time_request = (end_time_request - start_time_request).seconds
                                seconds_to_sleep = (15 * 60) - length_time_request

                                if (seconds_to_sleep > 0):
                                    print("sleeping for ", seconds_to_sleep / 60, " minutes", flush=True)
                                    time.sleep(seconds_to_sleep)  # Sleeps up to 15 minutes
                                    start_time_request = datetime.now()

                    except Exception as e:
                        valid_user = False
                        error_description = str(e)
                        exc_type, exc_obj, exc_tb = sys.exc_info()
                        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                        print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                              datetime.now(),
                              flush=True)

                    users_total += 1
                    # Update the DB
                    db[usersCollectionName].update_one({"_id": user['_id']},
                                        {"$set": {"bot_or_not_score": bot_score, "control.valid_user":valid_user,
                                                  "control.bot_or_not.error_description":error_description,
                                                  "control.bot_or_not.error_500":botometer_error}})

            # Write results and dictionaries on files
            print("Total users updated: %d" % (users_total))


            end_time = datetime.now()
            print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds))

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)