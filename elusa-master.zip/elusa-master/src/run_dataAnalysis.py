import sys


def main():
    from analysis.dataAnalysis import dataAnalysis

    # # Ask for the number and store it in userNumber
    # scenario = input('Enter 1 to First Scenario, 2 to Second Scenario and 3 to Third Scenario: ')
    # # Make sure the input is an integer number
    # scenario = int(scenario)
    #
    # if (scenario == 1):
    #     collection_name = 'timelines_only_eq_200_jan_nov_2016'
    #     folder_name = '/1_First Scenario'
    # elif (scenario == 2):
    #     collection_name = "timelines_gte_200_jan_nov_2016"
    #     folder_name = '/2_Second Scenario'
    # else:
    #     collection_name = "timelines_sampled_eq_200_jan_nov_2016"
    #     folder_name = '/3_Third Scenario'

    from pymongo import MongoClient

    # MongoDB connection
    client = MongoClient('mongodb://localhost:27017/')
    # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
    client.france_election.authenticate('josemar', 'pucmg$elusa$2016')
    print('Connected to MongoDB!', flush=True)
    db = client.elusa
    print('Connected to elusa DB!', flush=True)

    time_windows = [
       1, 2,
         3,
        7
    ]
    clusters = [
        1,
        2,
        3,
        4
    ]

    collection_name = 'timelines_sampled_eq_200_jan_nov_2016'
    folder_name = "3_Third Scenario"

    # Uncomment the line bellow to build the hashtag cloud files
    # dataAnalysis.buildMonthHashtagCloudsData(collection_name=collection_name, folder_name=folder_name, clusters=clusters)
    # dataAnalysis.generateMonthHashtagClouds(folder_name=folder_name, clusters=clusters)
    # dataAnalysis.buildEventHashtagCloudsData(collection_name=collection_name, folder_name=folder_name,
    #                                         time_windows=time_windows, clusters=clusters)
    # dataAnalysis.generateEventHashtagClouds(folder_name=folder_name, time_windows=time_windows, clusters=clusters)
    # dataAnalysis.timelineUsersAnalysisByMonth(collection_name=collection_name, folder_name=folder_name,  clusters=clusters)
    # dataAnalysis.timelineUsersAnalysisByEvent(db=db, collection_name=collection_name, folder_name=folder_name,
    #                                          clusters=clusters,yaxis_max_limit=0.5, yaxis_min_limit=-0.5,
    #                                         time_windows=time_windows)

    from datetime import datetime

    date_a = datetime(2016, 9, 1)
    date_b = datetime(2016, 12, 1)

    date_a_string = str(date_a).split(" ")[0]
    date_b_string = str(date_b).split(" ")[0]

    clusters = [
    1,
    2,
     3,
     4
    ]


    yaxis_max_limit=0.6
    yaxis_min_limit=-0.6
    month_locator_enabled=True

    start_time = datetime.now()

    for cluster in clusters:
        dataAnalysis.createOnePeriodDataAnalysis(cluster=cluster, db=db, folder_name=folder_name,
                                                 collection_name="features_set_sampled_eq_200_jan_nov_2016",date_a=date_a, date_b=date_b,
                                                 date_a_string=date_a_string, date_b_string=date_b_string,
                                    yaxis_max_limit=yaxis_max_limit, yaxis_min_limit=yaxis_min_limit,
                                                 month_locator_enabled=month_locator_enabled)

    end_time = datetime.now()
    print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
        start_time, end_time, (end_time - start_time).seconds))


if __name__ == '__main__':
    main()
