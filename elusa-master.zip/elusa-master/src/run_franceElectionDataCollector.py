import sys

"""
Run the scripts election France
"""
def main():

    from france_election_collectors.franceElectionDataCollector import franceElectionDataCollector

    scriptNumber = sys.argv[1]
    scriptToBeExecuted = int(sys.argv[2])
    usedTokens = int(sys.argv[3])

    if(scriptToBeExecuted == 0):
        #franceElectionDataCollector.createUserCollection()
        franceElectionDataCollector.fixRelationShipsCollection()
    elif(scriptToBeExecuted == 1):
        franceElectionDataCollector.getTweetsByFollowParameter(scriptNumber=scriptNumber, usedTokens=usedTokens)
    elif (scriptToBeExecuted == 2):
        franceElectionDataCollector.getTweetsByTrackParameter(scriptNumber=scriptNumber, usedTokens=usedTokens)
    elif (scriptToBeExecuted == 3):
        followedCandidate = int(sys.argv[4])
        candidateName = ('MLP_officiel' if (followedCandidate == 1) else 'EmmanuelMacron')
        franceElectionDataCollector.getCandidateFollowers(candidateName=candidateName, scriptNumber=scriptNumber, usedTokens=usedTokens)
    elif (scriptToBeExecuted == 4):
        totalTokens = sys.argv[4]
        franceElectionDataCollector.getUsersTimeline(scriptNumber=scriptNumber,
                                                     totalTokens=totalTokens,
                                                     usedTokens=usedTokens)
    elif(scriptToBeExecuted == 5):
        totalTokens = sys.argv[4]
        franceElectionDataCollector.getUsersFriends(scriptNumber=scriptNumber, totalTokens=totalTokens,
                                                     usedTokens=usedTokens)
    elif (scriptToBeExecuted == 6):
        totalTokens = sys.argv[4]
        franceElectionDataCollector.getUsersFollowers(scriptNumber=scriptNumber, totalTokens=totalTokens,
                                                    usedTokens=usedTokens)
    elif (scriptToBeExecuted == 7):
        totalTokens = sys.argv[4]
        franceElectionDataCollector.getFirstHopUsersTimeline(scriptNumber=scriptNumber,
                                                             totalTokens=totalTokens,
                                                                usedTokens=usedTokens)
    elif (scriptToBeExecuted == 8):
        totalTokens = sys.argv[4]
        franceElectionDataCollector.getFirstHopUsersFriends(scriptNumber=scriptNumber,
                                                            totalTokens=totalTokens,
                                                            usedTokens=usedTokens)
    elif (scriptToBeExecuted == 9):
        totalTokens = sys.argv[4]
        franceElectionDataCollector.getFirstHopUsersFollowers(scriptNumber=scriptNumber,
                                                              totalTokens=totalTokens,
                                                              usedTokens=usedTokens)
    elif (scriptToBeExecuted == 10):
        totalTokens = sys.argv[4]
        franceElectionDataCollector.buildUsersNetwork(scriptNumber=scriptNumber, totalTokens=totalTokens,
                                                    usedTokens=usedTokens)

    elif (scriptToBeExecuted == 11):
        totalTokens = sys.argv[4]
        franceElectionDataCollector.identifyInvalidUsers(scriptNumber=scriptNumber, totalTokens=totalTokens,
                                                    usedTokens=usedTokens)


if __name__ == '__main__':
    main()
