#!/usr/bin/python
"""
Script to perform data mining.
Author: Josemar Caetano
Date: 05/31/17
"""

path_name = '/home/josemar/Desktop/research_france/R'

import os
import sys
import subprocess
from datetime import datetime
import time

import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import numpy as np

import pickle


class dataMining:
    def __init__(self):
        pass

    def setClustersLabelsOnUserCollection(users_collections_names, folder_name, csv_name):
        try:
            data = pd.read_csv(os.path.join(path_name + "/"+folder_name + "/data/" + csv_name),
                               names=['X_id',
                                      'cluster'])

            timelines_collection_name = "timelines_sampled_eq_200_jan_nov_2016"
            users_collections_names = ['features_set_sampled_eq_200_jan_nov_2016',
                                       'users_politicalhashtags_sampled_eq_200_jan_nov_2016',
                                       'users_influential_sampled_eq_200_jan_nov_2016']

            from pymongo import MongoClient

            # MongoDB connection
            client = MongoClient('mongodb://localhost:27017/')
            #client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client.elusa.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            dbElusa = client.france_election
            print('Connected to elusa DB!', flush=True)

            for index, row in data.iterrows():
                for user_collection_name in users_collections_names:
                    dbElusa[user_collection_name].update_one(
                        {"_id": {"$eq":str(row['X_id'])}},
                        {"$set": {"class": int(row["cluster"])}})

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def setClustersLabelsOnDataCollections(dbElusa, timelines_collection_name, users_collections_names, folder_name, csv_name):
        try:
            data = pd.read_csv(os.path.join(path_name + "/data/" + csv_name),
                               names=['X_id',
                                      'cluster'])

            for index, row in data.iterrows():
                dbElusa[timelines_collection_name].update_many(
                    {"tweet.user.username": str(row['X_id'])},
                    {"$set": {"tweet.user.class": int(row["cluster"])}})
                for user_collection_name in users_collections_names:
                    #print(user_collection_name)
                    dbElusa[user_collection_name].update_one(
                        {"_id": {"$eq":str(row['X_id'])}},
                        {"$set": {"class": int(row["cluster"])}})
                try:
                    dbElusa['control_clustering_setting'].update_one({"_id":row["X_id"]},{"$set":{"class":row["cluster"]}},upsert=True)
                except Exception as e:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                    print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                          datetime.now(),
                          flush=True)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)


    '''
    Method used only for tests
    '''
    def testRefineClustersLabelsOnDataCollections(dbElusa, timelines_collection_name, featuresset_collection_name,
                                                  politicalhashtags_collection_name, influentialusers_collection_name,
                                              users_collections_names):
        try:
            print("==========================================")
            print("Setting refined clusters on data collections")
            print("==========================================")
            from pymongo import MongoClient

            start_time = datetime.now()

            users = dbElusa[featuresset_collection_name].find({'$or':[{"class":1}, {"class":2}]},no_cursor_timeout=True)

            # Change the dictionary values according to previous data mining/analysis results
            clusters = {'hillary_advocate': 1, 'trump_advocate': 2, 'political_bot': 3, 'normal_user': 4}

            total_changes_trump_to_hillary = 0
            total_changes_hillary_to_trump = 0

            for user in users:
                political_hashtags_usage = dbElusa[politicalhashtags_collection_name].find_one(
                    {'_id': {'$eq': user['_id']}}, no_cursor_timeout=True)

                if (political_hashtags_usage is not None):
                    if (user['class'] == clusters['hillary_advocate']):
                        refined_class = clusters['hillary_advocate']
                        if ((user['value']['sentiment_analysis']['political']['for_macron']['avg'] >
                                 user['value']['sentiment_analysis']['political']['for_lepen']['avg'])
                            or
                                (political_hashtags_usage['value']['percentage_macron_hashtags'] >
                                     political_hashtags_usage['value']['percentage_lepen_hashtags'])
                            ):
                            refined_class = clusters['trump_advocate']
                            total_changes_hillary_to_trump += 1
                    else:
                        refined_class = clusters['trump_advocate']
                        if ((user['value']['sentiment_analysis']['political']['for_lepen']['avg'] >
                                 user['value']['sentiment_analysis']['political']['for_macron']['avg'])
                            or
                                (political_hashtags_usage['value']['percentage_lepen_hashtags'] >
                                     political_hashtags_usage['value']['percentage_macron_hashtags'])
                            ):
                            refined_class = clusters['hillary_advocate']
                            total_changes_trump_to_hillary += 1


                if (refined_class == clusters['hillary_advocate']):
                    refined_class = clusters['hillary_advocate']
                    if ((user['biases']['towards_macron'] > user['biases']['towards_lepen'])):
                        refined_class = clusters['trump_advocate']
                        total_changes_hillary_to_trump += 1

                else:
                    refined_class = clusters['trump_advocate']
                    if ((user['biases']['towards_lepen'] >
                             user['biases']['towards_macron'])):
                        refined_class = clusters['hillary_advocate']
                        total_changes_trump_to_hillary += 1

                retweet_activity = dbElusa[influentialusers_collection_name].find_one(
                    {'_id': {'$eq': user['_id']}}, no_cursor_timeout=True)

                if (retweet_activity is not None):
                    if (refined_class == clusters['hillary_advocate']):
                        refined_class = clusters['hillary_advocate']
                        if (retweet_activity['value']['cluster_2_retweets'] > retweet_activity['value'][
                            'cluster_1_retweets']):
                            refined_class = clusters['trump_advocate']
                            total_changes_hillary_to_trump += 1

                    else:
                        refined_class = clusters['trump_advocate']
                        if (retweet_activity['value']['cluster_1_retweets'] > retweet_activity['value'][
                            'cluster_2_retweets']):
                            refined_class = clusters['hillary_advocate']
                            total_changes_trump_to_hillary += 1

                # if (user['class'] == clusters['hillary_advocate']):
                #     refined_class = clusters['hillary_advocate']
                #     if ((user['biases']['towards_trump'] > user['biases']['towards_hillary'])):
                #         refined_class = clusters['trump_advocate']
                #         total_changes_hillary_to_trump += 1
                # 
                # else:
                #      refined_class = clusters['trump_advocate']
                #      if((user['biases']['towards_hillary'] >
                #                  user['biases']['towards_trump'])):
                #         refined_class = clusters['hillary_advocate']
                #         total_changes_trump_to_hillary += 1
                # 
                # retweet_activity = dbElusa[influentialusers_collection_name].find_one(
                #     {'_id': {'$eq': user['_id']}}, no_cursor_timeout=True)
                # 
                # if(retweet_activity is not None):
                #     if (user['class'] == clusters['hillary_advocate']):
                #         refined_class = clusters['hillary_advocate']
                #         if (retweet_activity['value']['cluster_2_retweets'] > retweet_activity['value']['cluster_1_retweets']):
                #             refined_class = clusters['trump_advocate']
                #             total_changes_hillary_to_trump += 1
                # 
                #     else:
                #          refined_class = clusters['trump_advocate']
                #          if (retweet_activity['value']['cluster_1_retweets'] > retweet_activity['value'][
                #              'cluster_2_retweets']):
                #             refined_class = clusters['hillary_advocate']
                #             total_changes_trump_to_hillary += 1


                dbElusa[timelines_collection_name].update_many(
                    {"tweet.user.username": str(user['_id'])},
                    {"$set": {"tweet.user.class": refined_class}})
                for user_collection_name in users_collections_names:
                    dbElusa[user_collection_name].update_one({"_id": user['_id']},
                                                             {"$set": {"class": refined_class}})

            # Write results and dictionaries on files
            total_clustering_changes = total_changes_hillary_to_trump + total_changes_trump_to_hillary
            print("\nTotal changes: %d\nTotal TrumpToHillary changes: %d\nTotal HillaryToTrump changes: %d" % (
                total_clustering_changes, total_changes_trump_to_hillary, total_changes_hillary_to_trump))

            end_time = datetime.now()
            print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds))

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)



    def setClustersLabelsOnMoodVariationCollections(folder_name, featuresset_collection_name, mood_variation_collections):
        try:
            print("==========================================")
            print("Setting refined clusters on mood variation collections")
            print("==========================================")
            from pymongo import MongoClient

            # MongoDB connection
            client = MongoClient('mongodb://localhost:27017/')
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client.elusa.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            dbMoodVariation = client.mood_variation
            print('Connected to mood_variation DB!', flush=True)
            dbElusa = client.elusa

            users = dbElusa[featuresset_collection_name].find({"class":{'$ne':-1}},
                                                              no_cursor_timeout=True)
            for collection in mood_variation_collections:
                for user in users:
                    dbMoodVariation[collection].update_many(
                        {"username": str(user['_id'])},
                        {"$set": {"class": int(user["class"])}})

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)


    def createClusteringResultsCSV(folder_name, selected_features_set_csv_name,
                                                  users_set_csv_name, merged_csv_name):
        try:
            selectedFeaturesSet = pd.read_csv(os.path.join(path_name + "/"+folder_name + "/data/" + selected_features_set_csv_name),
                               names=['X_id',
                                      "tweet_syntax.words.std",
                                      "sentiment_analysis.political.for_hillary.std",
                                      "sentiment_analysis.political.for_trump.std",
                                      'class'])

            usersSet = pd.read_csv(os.path.join(path_name + "/" + folder_name + "/data/" + users_set_csv_name),
                                              names=['X_id',
                                                     'refined_class'])

            dataMerged = pd.merge(selectedFeaturesSet, usersSet, on='X_id', how='inner')

            dataMerged.to_csv(os.path.join(path_name + "/"+folder_name + "/data/" + merged_csv_name))


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def setPoliticalHashtagUsageAttributeOnUserCollection(featuresset_collection_name, politicalhashtags_collection_name):
        try:
            from pymongo import MongoClient

            start_time = datetime.now()

            # MongoDB connection
            client = MongoClient('mongodb://localhost:27017/')
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client.elusa.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            dbElusa = client.france_election
            print('Connected to elusa DB!', flush=True)

            users = dbElusa[featuresset_collection_name].find({},no_cursor_timeout=True)

            for user in users:
                political_hashtags_usage = dbElusa[politicalhashtags_collection_name].find_one(
                    {'_id': {'$eq': user['_id']}}, no_cursor_timeout=True)

                usage_for_trump = 0
                usage_for_hillary = 0

                if(political_hashtags_usage is not None):
                    usage_for_trump = political_hashtags_usage['value']['percentage_macron_hashtags']
                    usage_for_hillary = political_hashtags_usage['value']['percentage_lepen_hashtags']


                dbElusa[featuresset_collection_name].update_one({"_id": user['_id']},
                                                                 {"$set": {"political_hashtags.macron": usage_for_trump,
                                                                           "political_hashtags.lepen": usage_for_hillary}})

            end_time = datetime.now()
            print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds))

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    # TODO Still Working on it
    def createTimingAttribute(timelines_collection_name, featuresset_collection_name,
                                                  politicalhashtags_collection_name, users_collections_names):
        try:
            from pymongo import MongoClient

            start_time = datetime.now()

            # MongoDB connection
            client = MongoClient('mongodb://localhost:27017/')
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client.elusa.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            dbElusa = client.elusa
            print('Connected to elusa DB!', flush=True)

            users = dbElusa[featuresset_collection_name].find({"_id":"billmaher"},no_cursor_timeout=True)

            tweets_per_day = {}

            for user in users:
                tweets = dbElusa[timelines_collection_name].find({"tweet.user.username":{"$eq":user['_id']}},no_cursor_timeout=True)
                for tweet in tweets:
                    tweets_per_day[tweet['tweet']['created_at']] = []
                    tweets_per_day[tweet['tweet']['created_at']].append((0 if tweet['tweet']['retweet'] is True else 1))
                    tweets_per_day[tweet['tweet']['created_at']].append((1 if tweet['tweet']['retweet'] is True else 0))

                cluster_dataframe = pd.DataFrame(tweets_per_day,
                                                 columns=['created_at',
                                                          'tweet'
                                                          'retweet'
                                                          ])

                # Generate candidates' sentiment analysis per day
                cluster_dataframe['Date'] = pd.to_datetime(cluster_dataframe['created_at'])
                cluster_dataframe.index = cluster_dataframe['Date']
                del (cluster_dataframe['created_at'])

                users_daily_sentiment = cluster_dataframe.resample('D').mean()

                users_daily_sentiment.fillna(0)

                print(users_daily_sentiment)

                tweets_per_day_avg = 0

                print("\nSize:", len(users_daily_sentiment.index))


                # dbElusa[featuresset_collection_name].update_one({"_id": user['_id']},
                #                                                  {"$set": {"timing.tweets_per_day.avg": tweets_per_day_avg,
                #                                                            "timing.tweets_per_day.var": tweets_per_day_var}})

            end_time = datetime.now()
            print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds))

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

