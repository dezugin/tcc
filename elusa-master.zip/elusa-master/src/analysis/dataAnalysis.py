#!/usr/bin/python
"""
Script to visualize produced analysis.
Author: Josemar Caetano
Date: 05/31/17
PUC
"""
import sys
import os
import json
from datetime import datetime

import matplotlib.pyplot as plt
from asyncio import events
from pymongo import MongoClient
import calendar

import re
from collections import Counter
from wordcloud import WordCloud
from prettytable import PrettyTable

import matplotlib.dates as dates
import matplotlib.patches as mpatches

import pandas as pd

from datetime import timedelta

import logging

import pandas as pd

logging.basicConfig(level=logging.INFO,
                        format='(%(threadName)-10s) %(message)s', )

path_name = '/home/josemar/Desktop/R/'

months_intervals = [datetime(2016, 1, 1), datetime(2016, 2, 1), datetime(2016, 3, 1), datetime(2016, 4, 1),
                    datetime(2016, 5, 1), datetime(2016, 6, 1), datetime(2016, 7, 1), datetime(2016, 8, 1),
                    datetime(2016, 9, 1), datetime(2016, 10, 1), datetime(2016, 11, 1),
                    datetime(2016, 12, 1)]

months_intervals = [datetime(2016, 11, 1), datetime(2016, 12, 1), datetime(2017, 1, 1), datetime(2017, 2, 1),
                    datetime(2017, 3, 1), datetime(2017, 4, 1), datetime(2017, 5, 1), datetime(2017, 6, 1)]

events_dates =[
    {"date":datetime(2016, 9, 9),
     "description": "hillary_basket_deplorables",
     "text": "Hillary says that half of Trump's supporters are deplorables"},
    {"date":datetime(2016, 9, 11),
     "description": "hillary_health",
     "text": "Hillary gets sick and is caught by reporters"},
    {"date":datetime(2016, 9, 26),
            "description": "trump_audio_leak",
     "text": "Trump leaked tape"},
    {"date":datetime(2016, 10, 7),
     "description": "first_debate", "text": "First debate"
     },
    {"date":datetime(2016, 10, 9),
         "description": "second_debate", "text": "Second dabate"},
    {"date":datetime(2016, 10, 19),
         "description": "third_debate", "text": "Third dabate"},
    {"date":datetime(2016, 11, 9),
         "description": "election_day", "text": "Election day"}
]

candidates = ["realDonaldTrump", "HillaryClinton"]

class dataAnalysis:
    def __init__(self):
        pass

    def getClusterName(cluster_number):
        if(cluster_number == 1):
            return("Hillary's Advocates")
        elif(cluster_number == 2):
            return("Trump's Advocates")
        elif(cluster_number == 3):
            return("Political Bots")
        elif(cluster_number == 4):
            return("Regular Users")
        else:
            return("All clusters")

    def getFigureName(cluster_number):
        if (cluster_number == 1):
            return ('mean_sentiment_hillary.png')
        elif (cluster_number == 2):
            return ('mean_sentiment_trump.png')
        elif (cluster_number == 3):
            return ('mean_sentiment_political_bots.png')
        elif (cluster_number == 4):
            return ('mean_sentiment_regular_users.png')
        else:
            return ('mean_sentiment_all_users.png')

    def createOnePeriodDataAnalysis(cluster, db, folder_name, collection_name, date_a, date_b, date_a_string, date_b_string,
                                    yaxis_max_limit, yaxis_min_limit, month_locator_enabled):
        try:
            logging.info("Processing tweets from users of cluster "+str(cluster))
            # filename = path_name + folder_name + '/hashtagcloud/cluster_' + (
            #     str(cluster) if cluster != -1 else 'all') + '/data/'+date_a_string+'_'+date_b_string + '.data'
            # figure_name = path_name + folder_name + '/hashtagcloud/cluster_' + \
            #               (str(cluster) if cluster != -1 else 'all') + '/graficos/' + \
            #               '0_hashtag_cloud_interval_'+date_a_string+'_'+date_b_string+'.png'
            # summary_filename = path_name + folder_name + '/hashtagcloud/cluster_' + (
            #     str(cluster) if cluster != -1 else 'all') + "/summary/" + str(
            #     0) + "_"+date_a_string+'_'+date_b_string +"_hashtag_table.txt"
            # title = 'Hashtag cloud - ' + dataAnalysis.getClusterName(cluster) + '\n' + \
            #         str(calendar.month_name[date_a.month]) + "-" + str(calendar.month_name[date_b.month-1]) + " "+str(date_b.year)
            # 
            # dataAnalysis.buildOneHashtagCloudData(collection_name=collection_name, filename=filename, db=db,
            #                                        start_date=date_a, end_date=date_b, cluster=cluster)
            # 
            # dataAnalysis.generateOneHashtagCloudPlot(filename=filename, title=title, figure_name=figure_name,
            #                                          summary_filename=summary_filename)

            # sentiment_dataframe_name = path_name + folder_name + '/timeseries/data/cluster_' + (
            #     str(cluster) if cluster != -1 else 'all') + '/' + str(0) +"_"+date_a_string+'_'+date_b_string+"_mean_sentiment" + '.data'
            #
            # title = 'Daily mean sentiment towards candidates - ' + dataAnalysis.getClusterName(cluster) + '\n' + \
            #         str(calendar.month_name[date_a.month]) + "-" + str(calendar.month_name[date_b.month-1]) + " " + str(date_b.year)
            # # figure_name = path_name + folder_name + '/timeseries/graphics/cluster_' + (
            # #     str(cluster) if cluster != -1 else 'all') + '/' + str(0) +"_"+date_a_string+'_'+date_b_string+"_mean_sentiment" + '.png'
            # figure_name = path_name + folder_name + '/timeseries/graphics/'+dataAnalysis.getFigureName(cluster)
            # dataAnalysis.createOneSentimentTimeline(collection_name=collection_name, db=db,
            #                                         start_date=date_a, end_date=date_b, cluster=cluster,
            #                                         figure_name=figure_name, title=title, yaxis_max_limit=yaxis_max_limit,
            #                                         yaxis_min_limit=yaxis_min_limit,
            #                                         month_locator_enabled=month_locator_enabled, time_window=None,
            #                                         sentiment_dataframe_name=sentiment_dataframe_name)

            filename = path_name + folder_name + '/topiccloud/cluster_' + (
                str(cluster) if cluster != -1 else 'all') + '/data/' + date_a_string + '_' + date_b_string + '.data'
            figure_name = path_name + folder_name + '/topiccloud/cluster_' + \
                          (str(cluster) if cluster != -1 else 'all') + '/graficos/' + \
                          '0_topic_cloud_interval_' + date_a_string + '_' + date_b_string + '.png'
            summary_filename = path_name + folder_name + '/topiccloud/cluster_' + (
                str(cluster) if cluster != -1 else 'all') + "/summary/" + str(
                0) + "_" + date_a_string + '_' + date_b_string + "_topic_table.txt"
            title = 'Topic cloud - ' + dataAnalysis.getClusterName(cluster) + '\n' + \
                    str(calendar.month_name[date_a.month]) + "-" + str(
                calendar.month_name[date_b.month - 1]) + " " + str(date_b.year)

            dataAnalysis.createOneTopicCloudData(collection_name=collection_name, filename=filename, db=db,cluster=cluster,
                                                 title=title, figure_name=figure_name,
                                                 summary_filename=summary_filename
                                                 )

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)
            
    def createOneTopicCloudData(collection_name, filename, db, cluster,
                                title, figure_name,
                                summary_filename
                                ):
        try:
            users = db[collection_name].find({"class":cluster},no_cursor_timeout=True)

            all_topics = ''
            for user in users:
                try:
                    topics = user['syntax_usage']['main_timeline_topic']
                    for key, value in topics.items():
                        all_topics = all_topics + ''.join(key)
                except:
                    pass

            all_topics = str(all_topics).lower()
            all_topics = re.sub('[!?\\n#@$*]', '', all_topics)

            os.makedirs(os.path.dirname(filename), exist_ok=True)
            general_results_file = open(filename, 'w')
            general_results_file.write(all_topics)
            general_results_file.close()

            if (all_topics!= ''):
                # Generate a word cloud image

                wordcloud = WordCloud(background_color="white", width=1280, height=768).generate(all_topics)
                plt.imshow(wordcloud)
                frame1 = plt.gca()
                frame1.axes.get_xaxis().set_ticks([])
                frame1.axes.get_yaxis().set_ticks([])

                #plt.title(title, fontsize=24)

                os.makedirs(os.path.dirname(figure_name), exist_ok=True)
                plt.savefig(os.path.join(figure_name), dpi=120, format='png',

                            bbox_inches='tight')

                plt.close()

                words = re.findall(r'\w+', all_topics)
                total_words = len(words)
                word_counts = Counter(words)
                sorted_x = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
                topic_table = PrettyTable(['Topic', 'Frequency (%)'])

                for topic, freq in sorted_x[0:20]:
                    topic_table.add_row([topic, round(((freq / total_words) * 100), 2)])

                os.makedirs(os.path.dirname(summary_filename), exist_ok=True)
                orig_stdout = sys.stdout

                f = open(summary_filename, "w")
                sys.stdout = f

                print("Date: %s" % (datetime.now()))
                print("Data from file: %s " % (filename))
                print("Topic cloud table (10 most popular)")
                print(topic_table)
                sys.stdout = orig_stdout
                f.close()


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def buildOneHashtagCloudData(collection_name, filename, db, start_date, end_date, cluster):
        try:
            date_a = start_date
            date_b = end_date

            logging.info("Building hashtag cloud between "+str(date_a)+" and "+str(date_b)+"\tDatetime: "+str(datetime.now()))
            if (cluster != -1):
                tweets = db[collection_name].find({"$and": [
                    {"tweet.user.class": cluster},
                    {"tweet.syntax.total_hashtags": {'$gt': 0}}, {'tweet.created_at': {'$gte': date_a}},
                    {'tweet.created_at': {'$lt': date_b}}]}, {"tweet.user.username":True, "tweet.syntax.hashtags": True},
                    no_cursor_timeout=True)
            else:
                tweets = db[collection_name].find({"$and": [{"tweet.user.class": {"$ne":-1}},
                                                            {"tweet.syntax.total_hashtags": {'$gt': 0}},
                                                            {'tweet.created_at': {'$gte': date_a}},
                    {'tweet.created_at': {'$lt': date_b}}]}, {"tweet.user.username":True, "tweet.syntax.hashtags": True},
                    no_cursor_timeout=True)

            all_hashtags = ''
            for tweet in tweets:
                hashtags = tweet['tweet']['syntax']['hashtags']
                all_hashtags = all_hashtags + ''.join(hashtags)

            all_hashtags.replace("#", "")

            os.makedirs(os.path.dirname(filename), exist_ok=True)
            general_results_file = open(filename, 'w')
            general_results_file.write(all_hashtags)
            general_results_file.close()

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    """
    Function that filters the hashtags
    """
    def buildMonthHashtagCloudsData(collection_name, folder_name, clusters):
        try:
            # MongoDB connection
            client = MongoClient('mongodb://localhost:27017/')
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to elusa DB!', flush=True)

            for cluster in clusters:
                print("Processing hashtags from tweets of cluster ", cluster, flush=True)
                size = len(months_intervals) - 1

                date_a = months_intervals[0]
                date_b = months_intervals[size]
                filename = path_name + folder_name + '/hashtagcloud/cluster_' + (
                    str(cluster) if cluster != -1 else 'all') + '/data/0_all_months' + '.data'

                dataAnalysis.buildOneHashtagCloudData(collection_name=collection_name, filename=filename, db=db,
                                                    start_date=date_a, end_date=date_b, cluster=cluster)

                i = 0

                while (i < size):
                    date_a = months_intervals[i]
                    date_b = months_intervals[i + 1]
                    filename = path_name + folder_name + '/hashtagcloud/cluster_' + (
                        str(cluster) if cluster != -1 else 'all') + '/data/interval_month_' + str(
                        calendar.month_abbr[date_a.month]).lower() + '.data'

                    dataAnalysis.buildOneHashtagCloudData(collection_name=collection_name, filename = filename, db=db,
                                                        start_date=date_a, end_date=date_b, cluster=cluster)

                    i = i + 1


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def generateOneHashtagCloudPlot(filename, title, figure_name, summary_filename):
        try:
            logging.info("Generating hashtag cloud "+title+"\tDatetime: "+str(datetime.now()))
            general_results_file = open(filename, 'r')
            all_hashtags = general_results_file.read()
            general_results_file.close()

            if (all_hashtags != ''):
                # Generate a word cloud image
                wordcloud = WordCloud(background_color="white", width=1280, height=768).generate(all_hashtags)
                plt.imshow(wordcloud)

                frame1 = plt.gca()
                frame1.axes.get_xaxis().set_ticks([])
                frame1.axes.get_yaxis().set_ticks([])

                plt.title(title, fontsize=24)

                os.makedirs(os.path.dirname(figure_name), exist_ok=True)
                plt.savefig(os.path.join(figure_name), dpi=400, format='png',
                            bbox_inches='tight')

                plt.close()

                words = re.findall(r'\w+', all_hashtags)
                total_words = len(words)

                word_counts = Counter(words)
                sorted_x = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
                hashtag_table = PrettyTable(['Hashtag', 'Frequency (%)'])

                for hashtag, freq in sorted_x[0:20]:
                    hashtag_table.add_row([hashtag, round(((freq / total_words) * 100), 2)])

                os.makedirs(os.path.dirname(summary_filename), exist_ok=True)
                orig_stdout = sys.stdout
                f = open(summary_filename, "w")
                sys.stdout = f

                print("Date: %s" % (datetime.now()))
                print("Data from file: %s " % (filename))
                print("Hashtag cloud table (10 most popular)")
                print(hashtag_table)

                sys.stdout = orig_stdout
                f.close()

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    """
    Function that analyzes the feelings of the candidates timeline
    Using the library on https://github.com/amueller/word_cloud
    """
    def generateMonthHashtagClouds(folder_name, clusters):
        try:
            print("==========================================")
            print("ANALYSIS 1: Generating User Hashtag Cloud by Month")
            print("==========================================")
            for cluster in clusters:
                print("Processing hashtags from tweets of cluster ", cluster, flush=True)
                size = len(months_intervals) - 1

                filename = path_name + folder_name + '/hashtagcloud/cluster_' + (
                    str(cluster) if cluster != -1 else 'all') + '/data/0_all_months' + '.data'
                figure_name = path_name + folder_name + '/hashtagcloud/cluster_' + \
                              (str(cluster) if cluster != -1 else 'all') + '/graficos/' + \
                              '0_hashtag_cloud_interval_all_months.png'
                summary_filename = path_name + folder_name + '/hashtagcloud/cluster_' + (
                    str(cluster) if cluster != -1 else 'all') + "/summary/" + str(
                    0) + "_all_months_hashtag_table.txt"
                title = 'Hashtag cloud - ' + (str('Cluster ' + str(
                                cluster)) if cluster != -1 else 'All clusters') + '\n' + \
                        str(calendar.month_name[11])+" 2016 - "+str(calendar.month_name[5])+' 2017'

                dataAnalysis.generateOneHashtagCloudPlot(filename=filename, title=title, figure_name=figure_name,
                                                         summary_filename=summary_filename)

                i = 0
                while (i < size):
                    date_a = months_intervals[i]
                    year = "2016" if date_a.month > 10 else "2017"
                    filename = path_name + folder_name + '/hashtagcloud/cluster_' + \
                                   (str(cluster) if cluster != -1 else 'all') + '/data/interval_month_' + str(
                            calendar.month_abbr[date_a.month]).lower() +'.data'

                    title = "Hashtag cloud" +(str(' - Cluster ' + str(
                                          cluster)) if cluster != -1 else ' -  All clusters') + "\n" + str(
                                calendar.month_name[date_a.month]) + " "+year
                    figure_name = path_name + folder_name + '/hashtagcloud/cluster_' +\
                                          (str(cluster) if cluster != -1 else 'all') + '/graficos/month_intervals/' +\
                                          str(i) +'_hashtag_cloud_interval_' + \
                                          str(calendar.month_abbr[date_a.month]).lower() + '.png'

                    summary_filename = path_name + folder_name + '/hashtagcloud/cluster_' + (
                                str(cluster) if cluster != -1 else 'all') + "/summary/" + str(
                                i) + "_month_hashtag_table_" + str(calendar.month_abbr[date_a.month]) + ".txt"

                    dataAnalysis.generateOneHashtagCloudPlot(filename=filename, title=title, figure_name=figure_name,
                                                             summary_filename=summary_filename)

                    i = i + 1

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def buildEventHashtagCloudsData(collection_name, folder_name, time_windows, clusters):
        try:
            # MongoDB connection
            client = MongoClient('mongodb://localhost:27017/')
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client.elusa.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            db = client.elusa
            print('Connected to elusa DB!', flush=True)

            for cluster in clusters:
                size = len(events_dates)
                for i in range(size):
                    for time_window in time_windows:
                        print("Building event hashtags from tweets of cluster ", cluster,
                              "\tEvent: ", events_dates[i]['description'],
                              "\tTime Window: ", time_window, flush=True)
                        date_a = events_dates[i]['date'] - timedelta(days=time_window)
                        date_b = events_dates[i]['date'] + timedelta(days=time_window)
                        filename = path_name + folder_name + '/hashtagcloud/cluster_' + (
                            str(cluster) if cluster != -1 else 'all') + '/data/'+'event_' + str(i)+"_"+str(time_window) + \
                                   '.data'

                        dataAnalysis.buildOneHashtagCloudData(collection_name=collection_name, filename=filename, db=db,
                                                              start_date=date_a, end_date=date_b, cluster=cluster)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def generateEventHashtagClouds(folder_name, time_windows, clusters):
        print("==========================================")
        print("Generating User Hashtag Cloud by Event")
        print("==========================================")
        try:
            for cluster in clusters:
                size = len(events_dates)
                for i in range(size):
                    for time_window in time_windows:
                        print("Ploting event hashtags from tweets of cluster ", cluster,
                              "\tEvent: ", events_dates[i]['description'],
                              "\tTime Window: ", time_window, flush=True)
                        filename = path_name + folder_name + '/hashtagcloud/cluster_' + (
                            str(cluster) if cluster != -1 else 'all') + '/data/event_' + str(i)+"_"+str(time_window) + '.data'
                        title='Hashtag cloud' + " - " + str(
                            'Cluster ' + (str(cluster) if cluster != -1 else 'All Clusters') +
                            " - Time Window: "+str(time_window)+" day(s)"+
                            "\n" + str(events_dates[i]['text']))
                        figure_name = path_name + folder_name + '/hashtagcloud/cluster_' + \
                                                 (str(cluster) if cluster != -1 else 'all') + '/graficos/events/' + str(i) +\
                                      "_"+str(time_window) + '_hashtag_cloud_interval_' + str(events_dates[i]['description']+".png")
                        summary_filename = path_name + folder_name + '/hashtagcloud/cluster_' + \
                                           (str(cluster) if cluster != -1 else 'all') + "/summary/" + str(i) + "_"+str(time_window) + \
                                           "_event_hashtag_table_" + str(events_dates[i]['description']) + ".txt"

                        dataAnalysis.generateOneHashtagCloudPlot(filename=filename, title=title, figure_name=figure_name,
                                                                 summary_filename=summary_filename)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)


    def getDailyMeanIndexDataframe(df, new_column, current_column):
        df[new_column] = pd.to_datetime(df[current_column])
        df.index = df[new_column]
        del (df[current_column])
        users_daily_sentiment = df.resample('D').mean()
        users_daily_sentiment.fillna(0)

        return(users_daily_sentiment)

    def timelineUsersAnalysisByEvent(db, collection_name, folder_name, clusters, time_windows,
                                     yaxis_max_limit, yaxis_min_limit):
        try:
            print("==========================================")
            print("ANALYSIS 2: Building timeline User Analysis by Event")
            print("==========================================")
            for cluster in clusters:
                size = len(events_dates)
                for i in range(size):
                    for time_window in time_windows:
                        print("Processing event timeline from tweets of cluster ", cluster,
                              "\tEvent: ", events_dates[i]['description'],
                              "\tTime Window: ", time_window, flush=True)
                        date_a = events_dates[i]['date'] - timedelta(days=time_window)
                        date_b = events_dates[i]['date'] + timedelta(days=(time_window+1))

                        sentiment_dataframe_name = path_name + folder_name + '/timeseries/data/cluster_' + (
                            str(cluster) if cluster != -1 else 'all') + '/event/' + str(i) + "_" + str(
                            time_window) + "_" + str(events_dates[i]['description']) + '.data'

                        print(">>>",sentiment_dataframe_name)

                        title = str(events_dates[i]['text']) + "\n" + str(
                            'Cluster ' + str(cluster) if cluster != -1 else 'All Clusters') + " - Time Window: " + str(
                            time_window) + " day(s)"

                        figure_name = path_name + folder_name + '/timeseries/graphics/cluster_' + (
                            str(cluster) if cluster != -1 else 'all') + '/event/' + str(i) + "_" + str(
                            time_window) + "_" + str(events_dates[i]['description']) + '.png'

                        dataAnalysis.createOneSentimentTimeline(collection_name=collection_name, db=db,
                                                   start_date=date_a, end_date=date_b, cluster=cluster,
                                                   figure_name=figure_name, title=title,
                                                   yaxis_max_limit=yaxis_max_limit, yaxis_min_limit=yaxis_min_limit,
                                                   month_locator_enabled=False, time_window=time_window,
                                                                sentiment_dataframe_name=sentiment_dataframe_name)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def buildSentimentTimeline(collection_name, db, start_date, end_date, cluster):
        try:
            date_a = start_date
            date_b = end_date

            logging.info(
                "Processing sentiment timeseries between " + str(date_a) + " and " + str(date_b) + "\tDatetime: " + str(
                    datetime.now()))

            hillary_tweet_dict = {'created_at': [], 'sentiment_towards_lepen': []}
            trump_tweet_dict = {'created_at': [], 'sentiment_towards_macron': []}
            non_political_tweet_dict = {'created_at': [], 'sentiment_non_political': []}
            if (cluster != -1):
                tweets = db[collection_name].find({'$and': [
                    {"tweet.user.class": cluster}, {'tweet.created_at': {'$gte': date_a}},
                    {'tweet.created_at': {'$lt': date_b}}]},
                    no_cursor_timeout=True)
            else:
                tweets = db[collection_name].find({'$and': [
                    {"tweet.user.class": {"$ne": -1}}, {'tweet.created_at': {'$gte': date_a}},
                    {'tweet.created_at': {'$lt': date_b}}]},
                    no_cursor_timeout=True)

            for tweet in tweets:
                if (tweet['tweet']['semantics']['political']['macron'] is False
                    and tweet['tweet']['semantics']['political']['lepen'] is False):
                    non_political_tweet_dict['created_at'].append(tweet['tweet']['created_at'])
                    non_political_tweet_dict['sentiment_non_political'].append(
                        tweet['sentiment_analysis']['whole_text']['scale'])
                if (tweet['tweet']['semantics']['political']['lepen'] is True):
                    hillary_tweet_dict['created_at'].append(tweet['tweet']['created_at'])
                    hillary_tweet_dict['sentiment_towards_lepen'].append(
                        tweet['sentiment_analysis']['whole_text']['scale'])
                if (tweet['tweet']['semantics']['political']['macron'] is True):
                    trump_tweet_dict['created_at'].append(tweet['tweet']['created_at'])
                    trump_tweet_dict['sentiment_towards_macron'].append(tweet['sentiment_analysis']['whole_text']['scale'])

            hillary_cluster_dataframe = pd.DataFrame(hillary_tweet_dict,
                                                     columns=['created_at', 'sentiment_towards_lepen'])
            hillary_cluster_dataframe = dataAnalysis.getDailyMeanIndexDataframe(df=hillary_cluster_dataframe,
                                                                                new_column='Date',
                                                                                current_column='created_at')

            trump_cluster_dataframe = pd.DataFrame(trump_tweet_dict,
                                                   columns=['created_at',
                                                            'sentiment_towards_macron'
                                                            ])
            trump_cluster_dataframe = dataAnalysis.getDailyMeanIndexDataframe(df=trump_cluster_dataframe,
                                                                              new_column='Date',
                                                                              current_column='created_at')

            non_political_cluster_dataframe = pd.DataFrame(non_political_tweet_dict,
                                                           columns=['created_at',
                                                                    'sentiment_non_political'
                                                                    ])
            non_political_cluster_dataframe = dataAnalysis.getDailyMeanIndexDataframe(
                df=non_political_cluster_dataframe,
                new_column='Date',
                current_column='created_at')

            users_daily_sentiment = pd.concat(
                [hillary_cluster_dataframe, trump_cluster_dataframe, non_political_cluster_dataframe], axis=1)


            users_daily_sentiment.fillna(0)

            # print(users_daily_sentiment.head())



            return(users_daily_sentiment)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)
            return(None)

    def generateSentimentTimeline(sentiment_dataframe_name, figure_name, title, yaxis_max_limit, yaxis_min_limit,
                                  month_locator_enabled, time_window):
        try:
            logging.info(
                "Ploting sentiment timeseries: "+title+ "\tDatetime: " + str(
                    datetime.now()))

            users_daily_sentiment = pd.read_csv(os.path.join(sentiment_dataframe_name), header=None, index_col="Date",
                                                #parse_dates=True, #date_parser=dateparse,
                               names=['Date',
                                      'sentiment_towards_hillary',
                                      'sentiment_towards_trump',
                                      'sentiment_non_political'])

            users_daily_sentiment.index = pd.DatetimeIndex(users_daily_sentiment.index)

            #print(users_daily_sentiment.columns.to_series().groupby(users_daily_sentiment.dtypes).groups)

            fig, ax = plt.subplots()

            if (users_daily_sentiment is not None and len(users_daily_sentiment.index) > 0):
                hillary_line, = ax.plot(users_daily_sentiment['sentiment_towards_hillary'], linestyle='solid', marker='s',
                        color='blue', label='Towards Hillary', linewidth=2, markersize=8)
                trump_line, = ax.plot(users_daily_sentiment['sentiment_towards_trump'], linestyle='solid', marker='^', linewidth=2,
                        color='red', label='Towards Trump', markersize=8)
                non_political_line, = ax.plot(users_daily_sentiment['sentiment_non_political'], linestyle='solid', marker='o',
                                              color='green', label='Non Political',
                        linewidth=2, markersize=8)

                # ax.set_ylim([-1, 1])
                ax.set_ylim([yaxis_min_limit, yaxis_max_limit])

                # green_patch = mpatches.Patch(color='green', label='Non Political Sentiment')
                # blue_patch = mpatches.Patch(color='blue', label='Sentiment Towards Hillary')
                # red_patch = mpatches.Patch(color='red', label='Sentiment Towards Trump')
                # #plt.legend(handles=[blue_patch, red_patch])
                # plt.legend(handles=[green_patch, blue_patch, red_patch])

                plt.legend(handles=[hillary_line, trump_line, non_political_line], loc = 1, borderaxespad = 0.2)

                ax.grid(True)

                plt.axhline(0, color='black')
                # Add more locator tracks in order to process large images
                locator = dates.DayLocator()
                locator.MAXTICKS = 10000
                ax.xaxis.set_major_locator(locator)

                if (month_locator_enabled is True):
                    ax.xaxis.set_major_locator(dates.MonthLocator(interval=1))
                    ax.xaxis.set_major_formatter(dates.DateFormatter('%b'))
                elif (time_window is not None and time_window >= 3):
                    ax.xaxis.set_major_formatter(dates.DateFormatter('%d'))
                else:
                    ax.xaxis.set_major_locator(dates.DayLocator(interval=7))
                    ax.xaxis.set_major_formatter(dates.DateFormatter('%b %d, %Y'))

                # ax.xaxis.set_minor_locator(dates.HourLocator())
                plt.tight_layout()

                #plt.title(title, fontsize=24)

                plt.xlabel('Date', fontsize=20)
                plt.ylabel('Mean Sentiment', fontsize=20)

                plt.rcParams.update({'font.size': 14})

                os.makedirs(os.path.dirname(figure_name), exist_ok=True)

                plt.savefig(os.path.join(figure_name), dpi=150, format='png',
                            bbox_inches='tight')

            plt.close()

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)



    def createOneSentimentTimeline(collection_name, db, start_date, end_date, cluster,
                                   figure_name, title, yaxis_max_limit, yaxis_min_limit, month_locator_enabled, time_window,
                                   sentiment_dataframe_name):
        try:
           # users_daily_sentiment = dataAnalysis.buildSentimentTimeline(collection_name=collection_name, db=db,
           #                                                         start_date=start_date, end_date=end_date,
           #                                                              cluster=cluster)

           # os.makedirs(os.path.dirname(sentiment_dataframe_name), exist_ok=True)
           # users_daily_sentiment.to_csv(sentiment_dataframe_name,header=None)

           dataAnalysis.generateSentimentTimeline(sentiment_dataframe_name=sentiment_dataframe_name,
                                                   figure_name=figure_name, title=title,
                                                   yaxis_max_limit=yaxis_max_limit, yaxis_min_limit=yaxis_min_limit,
                                  month_locator_enabled=month_locator_enabled, time_window=time_window)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def timelineUsersAnalysisByMonth(collection_name, folder_name, clusters):
        try:
            print("==========================================")
            print("ANALYSIS 2: Building timeline User Analysis")
            print("==========================================")
            import pandas as pd

            # MongoDB connection
            client = MongoClient('mongodb://localhost:27017/')
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to elusa DB!', flush=True)

            size = len(months_intervals) - 1

            for cluster in clusters:
                print("Processing tweets from users of cluster ", cluster, flush=True)
                date_a = months_intervals[0]
                date_b = months_intervals[size]
                title='Daily mean sentiment towards candidates - ' + str('Cluster ' +
                                                                         str(cluster) if cluster != -1 else 'All clusters') + '\n' + \
                      str(date_a.strftime("%B"))+"-"+str(date_b.strftime("%B"))+" "+str(date_b.strftime("%Y"))
                month_locator_enabled = True
                figure_name = path_name + folder_name + '/timeseries/graphics/cluster_' + (
                    str(cluster) if cluster != -1 else 'all') + '/' + str(0) + "_" + str(
                    "2016 - 2017") + "_mean_sentiment" + '.png'
                sentiment_dataframe_name = path_name + folder_name + '/timeseries/data/cluster_' + (
                    str(cluster) if cluster != -1 else 'all') + '/month/' + str(0) + "_" + str(date_a.strftime("%B"))+"-"+str(date_b.strftime("%B"))+ '.data'
                dataAnalysis.createOneSentimentTimeline(collection_name=collection_name, db=db,
                                                        start_date=date_a, end_date=date_b, cluster=cluster,
                                           figure_name=figure_name, title=title, yaxis_max_limit=4, yaxis_min_limit=-4,
                                                        month_locator_enabled=month_locator_enabled, time_window=None,
                                                        sentiment_dataframe_name=sentiment_dataframe_name)


                i = 0
                month_locator_enabled = False
                while (i < size):
                    date_a = months_intervals[i]
                    date_b = months_intervals[i + 1]
                    title ='Daily mean sentiment towards candidates - ' + str(
                                'Cluster ' + str(cluster) if cluster != -1 else 'All clusters') + '\n' + str(date_a.strftime("%B %Y"))
                    figure_name = path_name + folder_name+ '/timeseries/graphics/cluster_' + (
                            str(cluster) if cluster != -1 else 'all') + '/month/' +str(i) + "_" + str(
                            calendar.month_abbr[date_a.month]).lower() + '.png'
                    sentiment_dataframe_name = path_name + folder_name + '/timeseries/data/cluster_' + (
                        str(cluster) if cluster != -1 else 'all') + '/month/' + str(i) + "_" + str(
                        date_a.strftime("%B")) + "-" + str(date_b.strftime("%B")) + '.data'

                    dataAnalysis.createOneSentimentTimeline(collection_name=collection_name, db=db,
                                                            start_date=date_a, end_date=date_b, cluster=cluster,
                                                            figure_name=figure_name, title=title, yaxis_max_limit=4,
                                                            yaxis_min_limit=-4,
                                                            month_locator_enabled=month_locator_enabled,
                                                            time_window=None,
                                                            sentiment_dataframe_name=sentiment_dataframe_name)

                    i = i + 1


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

