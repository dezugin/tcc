#!/usr/bin/python
"""
Script to get candidates tweets that were retweeted.
Author: Josemar Caetano
Date: 04/16/17
"""

import os
import sys
from datetime import datetime
import time

from pymongo import MongoClient

class processCandidatesTweets:
    def __init__(self):
        pass

    """
    This function deletes candidates tweets that weren't retweeted
    """
    def filterCandidatesTweets(collection_name):
        try:
            # MongoDB connection
            client = MongoClient('mongodb://localhost:27017/')
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client.elusa.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            dbElusa = client.elusa
            print('Connected to elusa DB!', flush=True)
            dbMoodVariation = client.mood_variation
            print('Connected to mood_variation DB!', flush=True)

            candidates_tweets = dbMoodVariation.tweets_candidates.find({})

            for candidates_tweet in candidates_tweets:
                totalRetweets = dbElusa[collection_name].count({"tweet.original_tweet.id":{"$eq":candidates_tweet['_id']}})
                dbMoodVariation.tweets_candidates.update_one({"_id":candidates_tweet['_id']}, {"$set":{"total_retweets":int(totalRetweets)}})

            dbMoodVariation.tweets_candidates.delete_many({"total_retweets":0})

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('External exception error: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, flush=True)


    """
    Function that shows the most popular tweets of each candidate
    """
    def showMostPopularTweets(self=None):
        try:
            start_time = datetime.now()
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            # client.elusa.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            dbElusa = client.elusa
            dbMoodVariation = client.mood_variation
            print('Connected to elusa DB!', flush=True)

            totalDocuments = 0

            import operator

            users = dbElusa.network.find(
                {'$or': [{"_id": {'$eq': "realDonaldTrump"}}, {"_id": {'$eq': "HillaryClinton"}}]},
                no_cursor_timeout=True)

            for user in users:
                tweetsRetweeted = user['tweets_retweeted']
                sorted_x = sorted(tweetsRetweeted.items(), key=operator.itemgetter(1), reverse=True)
                print("Most Popular Tweets of "+user['_id'])

                for i in range(10):
                    print(i+1, "\t", sorted_x[i])

                print("\n")

            end_time = datetime.now()
            print("\n\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds), flush=True)
            print("\n\tTotal documents: ", totalDocuments, flush=True)

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('External exception error: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, flush=True)

    """
    Function stores the amount of retweets from an official candidate tweet
    """
    def storeCandidatesTweetsRetweeted(self=None):
        try:
            start_time = datetime.now()
            # MongoDB connection
            #client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            #client.elusa.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            dbElusa = client.elusa
            dbMoodVariation = client.mood_variation
            print('Connected to elusa and mood_variation DBs!', flush=True)

            totalDocuments = 0

            import operator

            users = dbElusa.network.find({'$or':[{"_id":{'$eq':"realDonaldTrump"}},{"_id":{'$eq':"HillaryClinton"}}]}, no_cursor_timeout=True)

            for user in users:
                tweetsRetweeted = user['tweets_retweeted']
                for candidateTweetId in tweetsRetweeted:
                    totalDocuments+=1

                    totalRetweets = tweetsRetweeted[candidateTweetId]
                    print("ID: ", candidateTweetId, "\tRetweets: ", totalRetweets, "\tTotal processed: ", totalDocuments, flush=True)

                    candidateTweet = dbElusa.tweets.find_one({"tweet.original_tweet.id":int(candidateTweetId)}, no_cursor_timeout=True)

                    #print(candidateTweet)

                    candidateName = candidateTweet['tweet']['original_tweet']['user']['username']
                    sentimentAnalysis = candidateTweet['sentiment_analysis']['whole_text']['scale']
                    createdAt = candidateTweet['tweet']['original_tweet']['created_at']
                    text = candidateTweet['tweet']['original_tweet']['text']

                    document = {}
                    document['_id'] = candidateTweetId
                    document['candidate_name'] = candidateName
                    document['sentiment_analysis'] = sentimentAnalysis
                    document['created_at'] = createdAt
                    document['text'] = text
                    document['total_retweets'] = totalRetweets

                    dbMoodVariation.tweets_candidates.insert_one(document)

            end_time = datetime.now()
            print("\n\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds), flush=True)
            print("\n\tTotal documents: ", totalDocuments, flush=True)

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('External exception error: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, flush=True)

    """
    Function that stores candidate tweets
    """
    def storeColectedCandidatesTweets(self=None):
        try:
            start_time = datetime.now()
            # MongoDB connection
            #client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            #client.elusa.authenticate('josemar', 'pucmg$elusa$2016')
            print('Connected to MongoDB!', flush=True)
            dbElusa = client.elusa
            dbMoodVariation = client.mood_variation
            print('Connected to elusa DB!', flush=True)

            totalDocuments = 0
            totalDocumentsInserted = 0

            import operator

            tweets = dbElusa.tweets.find({'$or':[{"tweet.user.username":{'$eq':"realDonaldTrump"}},{"tweet.user.username":{'$eq':"HillaryClinton"}}]}, no_cursor_timeout=True)

            for tweet in tweets:
                totalDocuments+=1

                totalRetweets = 0
                print("ID: ", tweet['_id'], "\tRetweets: ", totalRetweets, flush=True)

                tweetAlreadyInserted = dbMoodVariation.tweets_candidates.find_one({"_id": tweet['_id']}, no_cursor_timeout=True)

                if(tweetAlreadyInserted is None):
                    candidateName = tweet['tweet']['user']['username']
                    sentimentAnalysis = tweet['sentiment_analysis']['whole_text']['scale']
                    createdAt = tweet['tweet']['created_at']
                    text = tweet['tweet']['text']

                    document = {}
                    document['_id'] = tweet['_id']
                    document['candidate_name'] = candidateName
                    document['sentiment_analysis'] = sentimentAnalysis
                    document['created_at'] = createdAt
                    document['text'] = text
                    document['total_retweets'] = totalRetweets

                    dbMoodVariation.tweets_candidates.insert_one(document)

            end_time = datetime.now()
            print("\n\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
                start_time, end_time, (end_time - start_time).seconds), flush=True)
            print("\n\tTotal documents: ", totalDocuments, flush=True)

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('External exception error: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, flush=True)