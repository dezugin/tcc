import sys

"""
Run the scripts election US
"""
def main():
    from twitter_data_collector.dataCollector import dataCollector

    from pymongo import MongoClient

    # MongoDB connection
    # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
    client = MongoClient('mongodb://localhost:27017/')
    client.elusa.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
    print('Connected to MongoDB!', flush=True)
    db = client.france_election
    print('Connected to france_election DB!', flush=True)

    scriptNumber = int(sys.argv[1])

    scriptToBeExecuted = int(sys.argv[2])

    usedTokens = int(sys.argv[3])

    if (scriptToBeExecuted == 0):
        dataCollector.setBotOrNotScoreOnClassifiedUsers(db=db, classified_users_collection="features_set_sampled_eq_200_jan_nov_2016",
                                                        users_collection="users")
    elif(scriptToBeExecuted == 1):
        totalTokens = sys.argv[4]
        dataCollector.getUsersBotOrNotScore(usersCollectionName="features_set_sampled",
                              scriptNumber=scriptNumber, db=db, totalTokens=totalTokens, usedTokens=usedTokens)


if __name__ == '__main__':
    main()

