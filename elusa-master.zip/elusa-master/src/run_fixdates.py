from collections import Counter
import re
import os
import sys
import subprocess
from datetime import datetime
import time

def main():
    from pymongo import MongoClient

    try:
        start_time = datetime.now()
        # MongoDB connection
        client = MongoClient('mongodb://localhost:27017/')
        #client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
        client.france_election.authenticate('josemar', 'pucmg$elusa$2016')
        print('Connected to MongoDB!', flush=True)
        print('Connected to mood_variation DB!', flush=True)
        db = client.france_election

        import dateutil.parser

        tweets = db.tweets.find({"tweet.created_at":{"$not":{"$lte": datetime(2018, 12, 31)}}},no_cursor_timeout=True)

        total = 0

        for tweet in tweets:
            old_created_at = tweet['tweet']['created_at']

            try:
                new_created_at = dateutil.parser.parse(old_created_at)
                #print(new_created_at)
                db.tweets.update_one({"_id":tweet['_id']},{'$set':{"tweet.created_at":new_created_at}})
                total += 1
                if (total % 100000 == 0):
                    print("Fixed until now: ", total, "\tAt ", str(datetime.now()), flush=True)
            except Exception as e:
                #print("Date already fixed - ID: ", tweet['_id'], "\tCreated at: ", old_created_at, flush=True)
                # if (total % 100000):
                #     print("Fixed until now: ", total ,flush=True)
                pass

        end_time = datetime.now()
        print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
            start_time, end_time, (end_time - start_time).seconds))
        print("Total fixed: ", total)

        print("##################### SCRIPT FINISHED ##########################")

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
              flush=True)


if __name__ == '__main__':
    main()