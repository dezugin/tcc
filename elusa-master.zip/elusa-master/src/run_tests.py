from collections import Counter
import re
import os
import sys
import subprocess
from datetime import datetime
import time

"""
Open archive
"""
def openfile(filename):
    fh = open(filename, "r+")
    str = fh.read()
    fh.close()
    return str


"""
Function that replaces characters
"""
def removegarbage(str):
    # Replace one or more non-word (non-alphanumeric) chars with a space
    str = re.sub(r'\W+', ' ', str)
    #str = str.lower()
    return str

"""
Function that gets the number of words
"""
def getwordbins(words):
    cnt = Counter()
    for word in words:
        cnt[word] += 1
    return cnt

"""
Function test
"""
def test(self=None):
    path_name = '/home/josemar/Desktop/R'
    filename = path_name + '/analysis/hashtagclound/cluster_all/event_' + str(0) + '.data'
    txt = openfile(filename)
    txt = removegarbage(txt)
    words = txt.split(' ')
    bins = getwordbins(words)
    for key, value in bins.most_common(25):
        print(key, value)

def testCreateUsersCollection(self=None):
    from france_election_collectors.franceElectionDataCollector import franceElectionDataCollector
    franceElectionDataCollector.createUserCollection()


def testebd(self=None):
    try:
        from pymongo import MongoClient
        from threading import Thread
        usersByScript = 1000
        # MongoDB connection
        client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
        #client = MongoClient('mongodb://localhost:27017/')
        client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
        print('Connected to MongoDB!', flush=True)
        db = client.france_election
        print('Connected to france_election DB!', flush=True)

        candidateIdsList = ['217749896', '1976143068']
        languagesList = ['fr']

        users = db.users_egonetworks.find({}, no_cursor_timeout=True).skip(int(0)).limit(usersByScript)

        finished_users = False

        for user in users:
            users_total_request = 0
            if user["timeline_collected"] is False:
                print(user["_id"])
                users_total_request += 1

            if(users_total_request == 15):
                print("15 users will be processed")

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
              flush=True)


def fixDates():
    from pymongo import MongoClient

    try:
        # MongoDB connection
        client = MongoClient('mongodb://localhost:27017/')
        #client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
        client.france_election.authenticate('josemar', 'pucmg$elusa$2016')
        print('Connected to MongoDB!', flush=True)
        print('Connected to mood_variation DB!', flush=True)
        db = client.france_election

        import dateutil.parser

        tweets = db.tweets.find({},no_cursor_timeout=True)

        for tweet in tweets:
            old_created_at = tweet['tweet']['created_at']

            try:
                new_created_at = dateutil.parser.parse(old_created_at)
                print(new_created_at)
                db.tweets.update_one({"_id":tweet['_id']},{'$set':{"tweet.created_at":new_created_at}})
            except Exception as e:
                print("Date already fixed - ID: ", tweet['_id'], "\tCreated at: ", old_created_at, flush=True)
                exc_type, exc_obj, exc_tb = sys.exc_info()
                fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                      flush=True)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
              flush=True)

def testeHashtagCloudSummary():
    import sys
    import os
    import json
    from datetime import datetime

    from asyncio import events
    from pymongo import MongoClient
    import matplotlib.pyplot as plt
    import calendar

    import re
    from collections import Counter
    from wordcloud import WordCloud
    from prettytable import PrettyTable

    import matplotlib.dates as dates
    import matplotlib.patches as mpatches
    all_hashtags = "abacate trump hillary maga trump maga macaco maga imwithher casa trofel"

    words = re.findall(r'\w+', all_hashtags)

    a = all_hashtags.split(" ")
    seen = set()
    result = []
    for item in a:
        if item not in seen:
            seen.add(item)
            result.append(item)

    print(len(result))

    total_words = len(words)

    word_counts = Counter(words)
    sorted_x = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
    hashtag_table = PrettyTable(['Hashtag', 'Frequency (%)'])

    print(sorted_x)

    for hashtag, freq in sorted_x[0:10]:
        hashtag_table.add_row([hashtag, round(((freq / total_words) * 100), 2)])

    print(hashtag_table)



def info(title):
    print(title)
    print('module name:', __name__)
    print('parent process:', os.getppid())
    print('process id:', os.getpid())

def f(name):
    info('function f')
    print('hello', name)


def testeParalelo(self=None):
    from multiprocessing import Process
    import os
    info('main line')
    p = Process(target=f, args=('bob',))
    p.start()
    print("KKKKK")
    p.join()

def testeDatas(self=None):
    from datetime import timedelta
    data_a = datetime(2016, 1, 1)
    data_b = data_a+ timedelta(minutes = 10)


    print(data_a)
    print(data_b)

def testeDictionary(self=None):
    events_intervals = [
        # {"a": datetime(2016, 3, 29), "b": datetime(2016, 4, 1), "description": "trump_women_must_be_punished",
        #  "text": "Trump says that women should be punished for abortion"},
        {"a": datetime(2016, 9, 8), "b": datetime(2016, 9, 11), "description": "hillary_basket_deplorables",
         "text": "Hillary says that half of Trump's supporters are deplorables"},
        {"a": datetime(2016, 9, 10), "b": datetime(2016, 9, 13), "description": "hillary_health",
         "text": "Hillary gets sick and is caught by reporters"},
        {"a": datetime(2016, 9, 25), "b": datetime(2016, 9, 28), "description": "first_debate", "text": "First debate"},
        {"a": datetime(2016, 10, 6), "b": datetime(2016, 10, 9), "description": "trump_audio_leak",
         "text": "Trump leaked tape"},
        {"a": datetime(2016, 10, 8), "b": datetime(2016, 10, 11), "description": "second_debate",
         "text": "Second dabate"},
        {"a": datetime(2016, 10, 18), "b": datetime(2016, 10, 21), "description": "third_debate",
         "text": "Third dabate"},
        {"a": datetime(2016, 11, 8), "b": datetime(2016, 11, 11), "description": "election_day", "text": "Election day"}]

    cluster  = 1
    i = 0
    title = 'Hashtag cloud' + " - " + str(
        'Cluster ' + (str(cluster) if cluster != -1 else 'All Clusters') +
                                                        "\n" + str(events_intervals[i]['text']))

    print(title)

def testBotometer():
    import os
    import sys
    from datetime import datetime
    import time

    import botometer

    scriptNumber = int(1)
    scriptNumber = scriptNumber + int(0)
    print('Executing getAuthAssociatedWithScript with scriptNumber = ', scriptNumber, flush=True)

    mod = __import__('configuration.authentication', fromlist=['authentication_' + str(scriptNumber)])
    auth = getattr(mod, 'authentication_' + str(scriptNumber))()

    consumer_key = auth.getconsumer_key()
    consumer_secret = auth.getconsumer_secret()
    access_token = auth.getaccess_token()
    access_token_secret = auth.getaccess_token_secret()

    mashape_key = "PEqZDZKZhQmshLNBkg5M8hZpsNJGp1HGd3Ejsn3sltP23YFRX3"
    twitter_app_auth = {
        'consumer_key': consumer_key,
        'consumer_secret': consumer_secret,
        'access_token': access_token,
        'access_token_secret': access_token_secret,
    }
    bom = botometer.Botometer(mashape_key=mashape_key, **twitter_app_auth)

    # Check a single account
    result = bom.check_account('@2thon')

    print(result)

    # Check a sequence of accounts
    accounts = ['@55Lidsville', '@ADL_2016', '@ActionTime']
    results = list(bom.check_accounts_in(accounts))

    print(results)

def testShowFriend():
    import os
    import sys
    from datetime import datetime
    import time

    import tweepy
    from pymongo import MongoClient

    from twitter_data_collector.dataCollector import dataCollector

    # Get access and key from another class
    auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=1, usedTokens=80)

    # Create the Tweepy API service
    api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True, retry_count=100, retry_delay=10,
                     retry_errors=set([401, 404, 500, 503]))



    source_user = "billmaher"
    # source_user = "BronsonShow"
    # target_user = "vice"
    target_user = "realDonaldTrump"

    relation = api.show_friendship(source_screen_name=source_user,
                                   target_screen_name=target_user)
    if relation[0].following is True:
        print("Source is following Target")
    if relation[1].following is True:
        print("Target is following Source")
    if relation[0].following is False and relation[1].following is False:
        print("There's no relationship")

if __name__ == '__main__':
    #test()
    #testeHashtagCloudSummary()
    #testeParalelo()
    #testebd()
    #testeDatas()
    #testeDictionary()
    #testBotometer()
    testShowFriend()