#!/usr/bin/python
"""
Script to get tweets of US Elections 2016 using Tweepy API.
Author: Josemar Caetano
Date: 08/22/16
"""

import os
import sys
from datetime import datetime

import time
import tweepy
from pymongo import MongoClient

from twitter_document_processing.tweetMethods import tweetMethods
from twitter_data_collector.dataCollector import dataCollector

class tweetsByTrackParameter(tweepy.StreamListener):

    def __init__(self, api, collectedTweets, db, tweetsCollectionName):
            super(tweetsByTrackParameter, self).__init__()
            self.api = api
            self.collectedTweets = collectedTweets
            self.db = db
            self.tweetsCollectionName = tweetsCollectionName

    def on_status(self, status):
        try:
            tweet = tweetMethods.createTweetDocument(r_tweet=status, fromStreaming=True, originalTweet=False)

          #  print('The final tweet:\n', json.dumps(tweet, sort_keys=True, indent=4), flush=True)
            self.db[self.tweetsCollectionName].insert_one(tweet)
            self.collectedTweets = self.collectedTweets + 1
            if (self.collectedTweets % 1000) == 0:
                print(self.collectedTweets, ' track tweets collected so far!', '\n\tDatetime: ', datetime.now(), flush=True)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\n[on_status] Error: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(), flush=True)


    def on_error(self, status_code):
        print('\n[on_error] Error: ', status_code, flush=True)
        time.sleep(2 * 60)
        return False

if __name__ == '__main__':
    try:
        scriptNumber = 1
        usedTokens = 60
        print('Executing getTweetsByTrackParameter with scriptNumber = ', scriptNumber, flush=True)
        track_list = ['#HeatherHeyer', 'Heather Heyer', '#resistance', '#WhiteSupremacist', "#WPWW", "#Conservative",
                     "#Redneck", "#BlackLivesMatter", "#NoHate", "#NoWhiteSupremacyHouse", "#NoRacism",
                     "#Charlottesville",
                     "#NotMyPresident", "#WhiteLivesMatter", "#RacismInChief", "#TrumpsArmy", "#WhiteNationalists"]

        languagesList=['en']

        tweetsCollectionName = 'tweets'

        from pymongo import MongoClient

        # MongoDB connection
        client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
        #client = MongoClient('mongodb://localhost:27017/')
        client.usa_hate_discourse.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
        print('Connected to MongoDB!', flush=True)
        db = client.usa_hate_discourse
        print('Connected to usa_hate_discourse DB!', flush=True)

        # Get access and key from another class
        auth = dataCollector.getAuthAssociatedWithScript(scriptNumber=scriptNumber, usedTokens=usedTokens)

        # Control variable to store the amount of collected tweets
        collectedTweets = 0
        # Create the Tweepy API service
        api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=False, retry_count=100,
                        retry_delay=10,
                        retry_errors=set([401, 404, 500, 503]))

        streamListener = tweetsByTrackParameter(api=api, collectedTweets=collectedTweets, db=db,
                                                tweetsCollectionName=tweetsCollectionName)
        # Establishes the authentication info, the service and the filter
        myStream = tweepy.Stream(auth=api.auth, listener=streamListener)
        # Get all tweets mentioning @realDonaldTrump and @HillaryClinton
        myStream.filter(track=track_list, languages=languagesList, async=True)

    except Exception as e:
       exc_type, exc_obj, exc_tb = sys.exc_info()
       fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
       print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
             datetime.now(), flush=True)