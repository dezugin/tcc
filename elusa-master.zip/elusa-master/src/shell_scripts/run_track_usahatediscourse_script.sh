#!/usr/bin/env bash
echo "CALLING TRACK COLLECTOR"
nohup python3 /home/josemar/development/python/elusa/src/run_tweetsByTrackParameter.py > out/tracktweets.out &

