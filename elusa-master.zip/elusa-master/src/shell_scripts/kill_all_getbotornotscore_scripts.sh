#!/usr/bin/env bash
ps -ef | grep "python3 /home/josemar/Documents/Development/Python/elusa/src/run_getBotOrNotScore" | awk '{print $2}' | xargs sudo kill