#!/usr/bin/env bash
#ps -ef | grep "python3 /home/josemar/Documents/Development/Python/elusa/src/run_usaHateDiscourse.py" | awk '{print $2}' | xargs sudo kill
ps -ef | grep "python3 /home/josemar/development/python/elusa/src/run_usaHateDiscourse.py" | awk '{print $2}' | xargs sudo kill