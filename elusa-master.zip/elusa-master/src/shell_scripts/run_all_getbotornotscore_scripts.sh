#!/usr/bin/env bash
echo "CALLING USER TIMELINE SCRIPTS"
for i in {1..30}
do
    echo "Calling BotOrNotScores $i thread"
    nohup python3 /home/josemar/Documents/Development/Python/elusa/src/run_getBotOrNotScore.py $i 1 0 30 > out/getbotornotscores_$i.out &
done








