#!/usr/bin/env bash
#echo "CALLING STREAM SCRIPTS"
#for i in {1..5}
#do
#    echo "Calling getTrack$i thread"
#    nohup python3 /home/josemar/development/python/elusa/src/run_usaHateDiscourse.py $i 2 0 > out/trackAPI.out & > out/trackAPI_$i.out &
#done

#echo "\n"

#echo "CALLING USER TIMELINE SCRIPTS"
#for i in {1..30}
#do
#    echo "Calling getUsersTweets $i thread"
#    nohup /home/josemar/development/python/elusa/src/run_usaHateDiscourse.py $i 4 5 30 > out/getuserstweets_$i.out &
#done
#
#echo "CALLING USER TIMELINE SCRIPTS"
#for i in {1..30}
#do
#    echo "Calling getUsersTweets $i thread"
#    nohup python3 /home/josemar/development/python/elusa/src/run_usaHateDiscourse.py $i 7 35 30 > out/seeduserstweets_$i.out &
#done

echo "CALLING USER FRIENDS SCRIPTS"
for i in {1..10}
do
    echo "Calling getUsersFriends $i thread"
    nohup python3 /home/josemar/development/python/elusa/src/run_usaHateDiscourse.py $i 5 61 10 > out/getfriends_$i.out &
done

echo "CALLING USER FOLLOWERS SCRIPTS"
for i in {1..10}
do
    echo "Calling getUsersFollowers $i thread"
    nohup python3 /home/josemar/development/python/elusa/src/run_usaHateDiscourse.py $i 6 71 10 > out/getfollowers_$i.out &
done







