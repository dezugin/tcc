#!/bin/bash
echo "CALLING BUILD USER NETWORK SCRIPTS"
for i in {1..82}
do
    echo "Calling getUsersFriends $i thread"
    nohup python3 /home/josemar/Documents/Development/Python/elusa/src/run_franceElectionDataCollector.py $i 10 0 82 > out/getfriends_$i.out &
done







