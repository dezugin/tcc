import sys


def main():
    from analysis.processCandidatesTweets import processCandidatesTweets

    # Ask for the number and store it in userNumber
    scenario = input('Enter 1 to First Scenario, 2 to Second Scenario and 3 to Third Scenario: ')
    # Make sure the input is an integer number
    scenario = int(scenario)

    if (scenario == 1):
        collection_name = 'timelines_only_eq_200_jan_nov_2016'
    elif (scenario == 2):
        collection_name = "timelines_gte_200_jan_nov_2016"
    else:
        collection_name = "timelines_sampled_eq_200_jan_nov_2016"

    # Uncomment the line bellow to build the hashtag cloud files
    processCandidatesTweets.filterCandidatesTweets(collection_name=collection_name)


if __name__ == '__main__':
    main()
