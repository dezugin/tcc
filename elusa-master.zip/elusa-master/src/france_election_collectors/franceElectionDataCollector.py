#!/usr/bin/python
"""
Script to get tweets of France election 2016 using Tweepy API.
Author: Josemar Caetano
Date: 04/25/17
"""

import os
import sys
from datetime import datetime
import time

import tweepy
from pymongo import MongoClient

from twitter_data_collector.dataCollector import dataCollector

from multiprocessing import Process


class franceElectionDataCollector:
    def __init__(self):
        pass

    def identifyInvalidUsers(scriptNumber, totalTokens, usedTokens):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            candidatesUsernameList = ['MLP_officiel', 'EmmanuelMacron']

            dataCollector.getInvalidUsers(users_collection_name="features_set_sampled",
                                          relationships_collection_name="relations_sampled", scriptNumber=scriptNumber,
                                          db=db,
                                          totalTokens=totalTokens, usedTokens=usedTokens,
                                          candidatesUsernameList=candidatesUsernameList)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def buildUsersNetwork(scriptNumber, totalTokens, usedTokens):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            candidatesUsernameList = ['MLP_officiel', 'EmmanuelMacron']

            dataCollector.getUsersNetwork(users_collection_name="features_set_sampled",
                                            relationships_collection_name="relations_sampled",scriptNumber=scriptNumber, db=db,
                                                  totalTokens=totalTokens, usedTokens=usedTokens,
                                                  candidatesUsernameList=candidatesUsernameList)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)


    """
    Function that obtains the parameters of the followers of the candidates
        :param usedTokens:
    """
    def getTweetsByFollowParameter(scriptNumber, usedTokens):
       try:
           # MongoDB connection
           #client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
           client = MongoClient('mongodb://localhost:27017/')
           client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
           print('Connected to MongoDB!', flush=True)
           db = client.france_election
           print('Connected to france_election DB!', flush=True)

           candidateIdsList =['217749896', '1976143068']
           languagesList=['fr']

           electionDataCollector.getTweetsByFollowParameter(candidateIdsList=candidateIdsList,
                                                            languagesList=languagesList, db=db,
                                                            scriptNumber=scriptNumber, usedTokens=usedTokens)

       except Exception as e:
           exc_type, exc_obj, exc_tb = sys.exc_info()
           fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
           print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                 datetime.now(), flush=True)

    """
    Function that obtains the parameters of the followers
        :param usedTokens:
    """
    def getTweetsByTrackParameter(scriptNumber, usedTokens):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            candidatesUsernameList=['@MLP_officiel', '@EmmanuelMacron']
            languagesList = ['fr']

            electionDataCollector.getTweetsByTrackParameter(candidatesUsernameList=candidatesUsernameList,
                                                             languagesList=languagesList, db=db,
                                                             scriptNumber=scriptNumber, usedTokens=usedTokens)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
            datetime.now(), flush=True)

    """
    Function that obtains followers of the candidates
        :param scriptNumber:
        :param usedTokens:
    """
    def getCandidateFollowers(candidateName, scriptNumber, usedTokens):
       try:
           # MongoDB connection
           # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
           client = MongoClient('mongodb://localhost:27017/')
           client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
           print('Connected to MongoDB!', flush=True)
           db = client.france_election
           print('Connected to france_election DB!', flush=True)

           dataCollector.getCandidateFollowers(candidateName=candidateName, db=db, scriptNumber=scriptNumber,
                                                       usedTokens=usedTokens)

       except Exception as e:
           exc_type, exc_obj, exc_tb = sys.exc_info()
           fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
           print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                 datetime.now(), flush=True)

    """
    Function that gets users timeline
        :param referenceValueToSkip:
        :param totalTokens:
        :param usedTokens:  
    """
    def getUsersTimeline(scriptNumber, totalTokens, usedTokens):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            electionDataCollector.getUsersTimeline(scriptNumber=scriptNumber, db=db,
                                                   totalTokens=totalTokens, usedTokens=usedTokens)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)


    def createUserCollection(self=None):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            from twitter_document_processing.tweetMethods import tweetMethods

            if("users" not in db.collection_names()):
                users = db.totaltimeline_users.find({},
                                                   no_cursor_timeout=True)

                for user in users:
                    userDocument = tweetMethods.createUserDocument(username=user['_id'],
                                                                   timelineCollected=True, hop=0)

                    db.users.insert_one(userDocument)

                print("Collections 'users' was created!", flush=True)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def fixRelationShipsCollection(self=None):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            from twitter_document_processing.tweetMethods import tweetMethods

            relationships = db.relationships.find({}, no_cursor_timeout=True)

            for relationship in relationships:
                relationshipDocument = tweetMethods.createRelationshipDocument(follower=relationship['follower'],
                                                                               followed=relationship['followed'])
                try:
                    db.new_relationships.insert_one(relationshipDocument)
                except Exception as e:
                    exc_type, exc_obj, exc_tb = sys.exc_info()
                    fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
                    print('\nrelationship already inserted: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno,
                          '\tDatetime: ', datetime.now(), flush=True)

            print("\n\n###########################################################\tSCRIPT FINISHED.", flush=True)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def getUsersFriends(scriptNumber, totalTokens, usedTokens):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            candidatesUsernameList = ['MLP_officiel', 'EmmanuelMacron']

            totalDocuments = db.users.count({'$and': [{"valid_user": True}, {'hop': 1}]})

            dataCollector.getUsersFriends(users_collection_name="features_set_sampled", relationships_collection_name="relations", scriptNumber=scriptNumber, db=db,
                                                   totalTokens=totalTokens, usedTokens=usedTokens, candidatesUsernameList=candidatesUsernameList)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def getUsersFollowers(scriptNumber, totalTokens, usedTokens):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            candidatesUsernameList = ['MLP_officiel', 'EmmanuelMacron']

            dataCollector.getUsersFollowers(users_collection_name="features_set_sampled", relationships_collection_name="relations",scriptNumber=scriptNumber, db=db,
                                                  totalTokens=totalTokens, usedTokens=usedTokens,
                                                  candidatesUsernameList=candidatesUsernameList)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def getFirstHopUsersFriends(scriptNumber, totalTokens, usedTokens):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            candidatesUsernameList = ['MLP_officiel', 'EmmanuelMacron']

            electionDataCollector.getFirstHopUsersFriends(scriptNumber=scriptNumber, db=db,
                                                   totalTokens=totalTokens, usedTokens=usedTokens, candidatesUsernameList=candidatesUsernameList)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    def getFirstHopUsersFollowers(scriptNumber, totalTokens, usedTokens):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            candidatesUsernameList = ['MLP_officiel', 'EmmanuelMacron']

            electionDataCollector.getFirstHopUsersFollowers(scriptNumber=scriptNumber, db=db,
                                                  totalTokens=totalTokens, usedTokens=usedTokens,
                                                  candidatesUsernameList=candidatesUsernameList)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)

    """
    Function that gets users timeline
        :param referenceValueToSkip:
        :param totalTokens:
        :param usedTokens:
    """

    def getFirstHopUsersTimeline(scriptNumber, totalTokens, usedTokens):
        try:
            # MongoDB connection
            # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
            client = MongoClient('mongodb://localhost:27017/')
            client.france_election.authenticate('josemar', 'pucmg$elusa$2016', source='admin')
            print('Connected to MongoDB!', flush=True)
            db = client.france_election
            print('Connected to france_election DB!', flush=True)

            electionDataCollector.getFirstHopUsersTimeline(scriptNumber=scriptNumber, db=db,
                                                   totalTokens=totalTokens, usedTokens=usedTokens)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ', datetime.now(),
                  flush=True)