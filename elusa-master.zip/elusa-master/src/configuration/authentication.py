"""
File to store Twitter App's keys and tokens
Author: Josemar Caetano
Date: 08/20/16
"""

class authentication_1():

    def __init__(self):
        self.consumer_key ='bF517AHO4argSSGkYO2telCFX'
        self.consumer_secret='kZCErQPCfL2CDK8jm0weB3apF5zYtjxACKyJhDfwdg3b4nTRfo'
        self.access_token='1952939204-8vq8imAFkVtSZdMgD6hZpAx6QIfpoJDQi6ekqvO'
        self.access_token_secret='jM4fMB96uQnvGoxEISvX5ddSAXpSahzPR3MbMaI8kHWF2'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_2():

    def __init__(self):
        self.consumer_key ='Gy6TXdv5MUt0Zwy28nOYrMgQe'
        self.consumer_secret='4j69AeYiwRcyvAhU0oyJV5ZyyJDCg330ZTYehMBHa7TzUVoVw6'
        self.access_token='1952939204-xLSGj8iCK2cW3fFXSEpT7UesaYOaJgcoKbtAmW0'
        self.access_token_secret='SewIaRuHt2ZdUzQUd3kgaCN5r4tfr5AX2qR0iftiWaRQ6'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_3():
    def __init__(self):
        self.consumer_key ='8DjW9XZBoPVM7VLhi2dIwe4E3'
        self.consumer_secret='gZliwWtn9EegfS8h9eB4E1gvltw7ISlLADkuaZU0rk1mo1AXS3'
        self.access_token='1952939204-Hkqhvtm7zLBMJ7YTuvaOqEuYBWrzkwJl3dwP3rN'
        self.access_token_secret='2rBeZnGy9pA4zWD78LAzX5arYOBecVX6dnFmSLyCsLmHF'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_4():
    def __init__(self):
        self.consumer_key ='WT2caVM7iyQz0vsgYVTIh5Dvb'
        self.consumer_secret='swCORj7Kau3W9s73Vt7SkIdx8fN4X59bjSUJdxtU9J2Mwyhdnc'
        self.access_token='1952939204-NIPP3FfXhTAlaDNfLNR5rSvSF1e0dRnkAxi1Zt8'
        self.access_token_secret='aaRIdiEiFSvg3cmllJX37Luz2lkcOXXTnaLEkHYbiVYF9'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_5():
    def __init__(self):
        self.consumer_key ='renhhuowHfrOBfRvl30b0iv9E'
        self.consumer_secret='teryH1Gty9k4Z7ONy33kDEMxH8uo5untTMnrSTTRNjFkneZRPu'
        self.access_token='1952939204-dWwRTyMMPKMzcCvpY4MEkbRY3RflF08MOV4I6xF'
        self.access_token_secret='0PHqEq3Dvd6OyhTieoesqJZ56ddrdCtybJgjjrkinejMn'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_6():
    def __init__(self):
        self.consumer_key ='szKCFl4Z9dunuB7VMiyeQSabd'
        self.consumer_secret='xU3oROnjL8PURxMGbKny4os3AqajxYCvXMd0lCt1nE72JyE8Ee'
        self.access_token='1952939204-JxhlReIE73t1cinqN9tALPxppJUPiTY3VvF6vVs'
        self.access_token_secret='54zyr6dUoUOX2WnixYnQKGnHho1UGMai6vfgMifChUmbB'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_7():
    def __init__(self):
        self.consumer_key ='M8b4wiO08mzdtitkVylugDP6h'
        self.consumer_secret='3ZltFvW7eAq4YAaU8YIH4YPXJ4xbmvL5xgFdJrP81fdMt2INlN'
        self.access_token='1952939204-RkhTK5j9CJg2p0bpsezoSjdyVTrGmmXlmIooCFv'
        self.access_token_secret='3CaE9k7jVRbYjDE94LsR4a9jy3eW8H6zSVCzn9F4tNAwF'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_8():
    def __init__(self):
        self.consumer_key ='aKRyVyxMVbLtKy5bO0fmCyBU8'
        self.consumer_secret='mpM7dWnIEdEOMCT1Hi2o4ixdLCcfeY8fRMboSvL6JMCUiWhquw'
        self.access_token='1952939204-iVM5tDZwHm5ti5PpUkyBEDhTfTRnpsZqP3xkmzC'
        self.access_token_secret='DQHdfzFAt1CguXIbFi01vtBd7eelIp9fTaVKkoP5MFoD6'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_9():
    def __init__(self):
        self.consumer_key ='WrVzbQCv6tlBp01hfyocsxUTD'
        self.consumer_secret='7fd94i0mGueYBd2E42iJX0UFo0bJXmOTzgxK0dfFkNHpMKujtk'
        self.access_token='1952939204-m9hooA6nYcBe7urrj0ySwaUGkYivZJQsLTQoAaK'
        self.access_token_secret='iQU2L8ITvQrYyFP2sOWxhiYz8j0a6kRn5AqMG8IEug39m'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_10():
    def __init__(self):
        self.consumer_key ='aEFwboVZkuyaycRFPUKrckw0u'
        self.consumer_secret='4DYY58oq8d3kHGQ1yYIYOPZn6uVaPv96AaGhEszGRJFVr6ZR9E'
        self.access_token='1952939204-HEziSbK0KjXyGmHXI0a8QkOLKGlc05OVvqlCztt'
        self.access_token_secret='1pSm8DY9U9GCgHWhAeB3WVesQKA8ZVEEJPEuzzmWaAIJu'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_11():
    def __init__(self):
        self.consumer_key = 'IN5x7t6C6ebsLcHIXwYq35G8r'
        self.consumer_secret = 'k4PxgldjnnqTqH65cKF5I6vSCba1exfgQguxflWgoRX0wHWSjC'
        self.access_token = '1952939204-qaMDoOFhYJkImwrbLOGlIAiOH5ICecwr3qkbI29'
        self.access_token_secret = 'qdjVTqYgL05RfxuSCqI5o9fxx0Pt4zPnm6utVeuPtXwFJ'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_12():
    def __init__(self):
        self.consumer_key = 'X97vE7s1i4MdFTMUevls49XUO'
        self.consumer_secret = 'IjMFYQq1vSLRotwZJ1i7lp401uMKodYGsYsv6OrqqRGsj9G7cv'
        self.access_token = '1952939204-T9SGRdLdcFDwGJZ8L4yDurfHrvZTHIxxkg9hjIc'
        self.access_token_secret = 'rP1cOLRwQgG8x1QP7os1Pr99kfXGdiZK2ov6sGaK8Pkdz'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_13():
    def __init__(self):
        self.consumer_key = 'xZaP79L1G2Hym2PfUkotLWFVC'
        self.consumer_secret = 'YuGGpcM8135uHUVrtAzvIFMaYLfFbA4ozWCuZv8GNWer9kH3Tj'
        self.access_token = '1952939204-QZyQz8AhFvimS8Xfdu5WK7JdnyArnWLC9xLf2Om'
        self.access_token_secret = '9fmermra09iqTu2GcHSDtmUGtMW2VR6QVvBhCaR7Xqnkj'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_14():
    def __init__(self):
        self.consumer_key ='0LgTnDGJftXENQKV5p45GWa2U'
        self.consumer_secret='KQviUS9e6sh2jzwTzrMGAN2KI3vIfafCAxHekvsoqruq81Zway'
        self.access_token='1952939204-TZc4dBMHtuNKiNDMkofBEF2GImZHilLQxP5AkWe'
        self.access_token_secret='DUuGTQy7gjTXT1jROxMLuxsRTPkVptMub4UUovPdtsJhS'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_15():
    def __init__(self):
        self.consumer_key ='pRFb3JwkECwRRsdgwd2hxjtUF'
        self.consumer_secret='CKPuFMXjrjXh8fpmGbmUcm58w4XioWkEsMAwIS8thwmMUJ0Hl2'
        self.access_token='1952939204-00xQMqSTnkH9bpJxb7x0Lvi6fWKwvYaLdFSVl1t'
        self.access_token_secret='Lk90T3iKKUayHrtWG5njvPte5jaz9ixEtmf1LFNHMuF7F'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_16():
    def __init__(self):
        self.consumer_key ='pJsOB23lxycxWtx5BbPYbAKeL'
        self.consumer_secret='GDnegwPCpITI80PhoJoUl2U4zsR5P1oJo6io1ID0n4ACRbZo75'
        self.access_token='1952939204-939gDgzEp4WeHCixCLBQo0IpZCJNocgmlmVi41t'
        self.access_token_secret='mkQxX3dOTiN1raD7cYHiCjVsWV9YjxeNfYGGZJAOaJU87'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_17():
    def __init__(self):
        self.consumer_key ='oKTn5JAWOIhcUmWkBf3TIIn16'
        self.consumer_secret='s5MCW3GSfFpWMyj1kHXTXwAdqZIbDSC54yTZAyjVVmgBEaCh4W'
        self.access_token='1952939204-KYi6EEBfBhfwBGkZp0mPH6CexON0fZEsooNPJDY'
        self.access_token_secret='fdkai5Y9d9qtlNpYngDQZUPRd8pGDZCJEt9WxxNoRJJra'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_18():
    def __init__(self):
        self.consumer_key ='jIRFymB0T2woInylolbA9z1AT'
        self.consumer_secret='i1XKwd0rFuxubEd0UHJXw0XOQmnBEUiU1wwyURgnrlrHuw8RzO'
        self.access_token='1952939204-Z9aRLU1geuA8sbvapuaZO2wKBy0FLH66fv0ttqU'
        self.access_token_secret='xkWxZKHbvTcFOErYRvjCL3fWRAvdTvf2XVIiGUPP3Ouf7'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_19():
    def __init__(self):
        self.consumer_key ='8h2cmzj5Vf7g1w5M5i9Mxhc9k'
        self.consumer_secret='zZgSdJbaYnExP8whz631Uys8oStYcrr8SMm7mtZWB5zOjNoyGg'
        self.access_token='1952939204-B6db8xAhImfN8LpleyL0UcirCVbuOoOh2Htrgin'
        self.access_token_secret='6lNcVn4hVMFaYjUYQkq2pskHc6FJhDMHy7BwxiPwrx4a3'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_20():
    def __init__(self):
        self.consumer_key ='J6sKJhXqQhN1ZXA0Uva9yjl3v'
        self.consumer_secret='yEWfmXHj3Om843eMs1fk6vkBVudxZrbjNsKReoUgTpgZrhkKsd'
        self.access_token='1952939204-yv9FwR1UEuosVgRoXymdbyX5umym2LgU232FglL'
        self.access_token_secret='1SACTZuFISAT9Nq4UZQ6gBsOy0XWzg7qW1CvhK9VovREK'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_21():
    def __init__(self):
        self.consumer_key ='R1utrywaMMdghRAyQrDFMICOG'
        self.consumer_secret='pZ45IHr2zEBgGlJgvbGZnZbDGlO1D2YQKOBpWGxhgyWgTBXaFP'
        self.access_token='1952939204-lL5UQzC8huAdR167uCYOiAuJZXvWwV1jiiWRfLx'
        self.access_token_secret='kNBpYaNRu8TYzeEsTNaryIwQLF0EKeJLlZNzEiZHGMuib'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_22():
    def __init__(self):
        self.consumer_key ='pvEZXUfRdsOssp0YtuB6KYIRF'
        self.consumer_secret='Di7sDJSV6Wvsq1YK22MnN6CmE0oYLdRtx1nWIbcDQ78rpYNgQh'
        self.access_token='1952939204-QTMES2vkBUiBfE6rYyC63QwpqjhfBfL8UBwSdCZ'
        self.access_token_secret='rWNrL7BZwMR6TvX4GHfyH7KD6EpxT3jYc1VHalZ5fcJ3W'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_23():
    def __init__(self):
        self.consumer_key ='J6cFECGKlcfxzkPXwkok5uILO'
        self.consumer_secret='3GU8W0rJdBvM7W4tWVdMyXyM8Rva9iiCBwYbNLlkaupeKDXgp5'
        self.access_token='1952939204-3wSRTZZd6jNHhnAYb96yf726vTh6PzscCa4opU2'
        self.access_token_secret='cmDvDPSH4TK4KmrYyhMXIzd9G2fBrLzlcsalbHQ3lBaaS'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_24():
    def __init__(self):
        self.consumer_key ='hgGqS9HVpB1mxTmrnYlEfNNdv'
        self.consumer_secret='xHk6FwBTHRGHH13XLH8dnau4axZUoC5hVJIZdg3Sk7Ly0SY26A'
        self.access_token='1952939204-w84hMO9p06gjyQ80y4UxwvBG3eLV5j2G1rsLwVG'
        self.access_token_secret='W6hwmihQABUrbzjUyX9rjrLBiVKNVFt0kl4w3MajRBO52'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_25():
    def __init__(self):
        self.consumer_key ='oCsAfC3yVhLL19S3sk0nFgNSw'
        self.consumer_secret='O3ef0RBwDlP3rIbr3NkdFlDyjqFbe5oViuKBHSDwx7d8r1TGWK'
        self.access_token='1952939204-zfgp4KLJwDsh5jV6yDQjsX3OZH0NNH5zKLntNwj'
        self.access_token_secret='cVwQPpnOst9PKRGJCBxVnkFW0ILdE5DIou4mod4l3gIaf'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_26():
    def __init__(self):
        self.consumer_key ='2o6IPyi7VfLKpfWVR7plEmue7'
        self.consumer_secret='EuUTpqL1JibNDI39fXEgHFgjfwAPtBZXHD8hUCCrdGYDjTA6AV'
        self.access_token='1952939204-p9LtODc0MakiK1fTxfTvqL9pS1i1OLSkt7pbeWQ'
        self.access_token_secret='GCIppJXmp7d5E41EtVXkBuel3vSH10zdEra5z5DVOHKGI'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_27():
    def __init__(self):
        self.consumer_key ='S0tcf4a7LyVZBYdCyVOhYRx7z'
        self.consumer_secret='JpzUMfEfHAeRFfjuJmrkJrliFRN1uZNTdqyTCsPKQFSvtpOn3G'
        self.access_token='1952939204-eFYl9JK6Z6aLBI1fTH8IhHNDqcl0eiNHRVyCnDs'
        self.access_token_secret='sclPpQYSLtUT6QPCmUDkS2z4sAa6DDaiOzzS18JZTD2ew'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_28():
    def __init__(self):
        self.consumer_key ='qZrxKTFz36WULviakt3aDNdq8'
        self.consumer_secret='0e16z70VS8Kq7djqvEmTnMaGiwQkoswCwvBvR5O5jPF0qsqGt3'
        self.access_token='22767625-iaH4OOrIH1bGqTkQUc4OzgkhHKuehZltGwTFVRMK8'
        self.access_token_secret='OJwHIO78xlK6muvWruEQx1LtszVRbCYgBC24qryY5Sn38'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_29():
    def __init__(self):
        self.consumer_key ='AovRKc2zYAVBDlPFYGxDeKePu'
        self.consumer_secret='djPHne37MkpNrkOlyoeinbDospA39RC38r4VFR1Dr8UIJqsTie'
        self.access_token='22767625-3RgS8vZpUsF2dHLvIsIm6y7HrD8EmpF95twn0j31g'
        self.access_token_secret='xUIQjJ3x17lPdB0Qrm7nlEVTUyVkLsMI8CUjwHZYI6niz'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_30():
    def __init__(self):
        self.consumer_key ='asa1FLG93bGf8cDUxJTs6pjoP'
        self.consumer_secret='WlSR84r4Zn1ZnFvuPaFUkMpXWQ3Gi55HT97KXkpC4H61cJ1x8d'
        self.access_token='22767625-ZQ33Hth834RXdetHnxnQFoEKOtBMcRX4uMeb0T10o'
        self.access_token_secret='n0jCUmROEtC8D2lglrmVZkuKrB1JxJtkM0o0dyEopWakJ'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_31():
    def __init__(self):
        self.consumer_key ='xxtXhTk4cU8v3A1U9ATkOuDCa'
        self.consumer_secret='Jsec0NlMCOWAop7P69z0VGlB6BljspT2qjT7nO4wRD65wqyI1r'
        self.access_token='31271710-HtZWL6AgTi0xMtw68arYR8G8UTTOpRJJqvrGECbDK'
        self.access_token_secret='fanurXyB41lF4hTHKhK6mJWyR9SQJBXbWy8PNM026Ta7H'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_32():
    def __init__(self):
        self.consumer_key ='RxhQ6FEBpxle0gLf7iq2s4D4l'
        self.consumer_secret='hbQuBLeKQLJLn2XDp8rqVPtREsSiOGxGkgBnZOGSr0Hi64dngm'
        self.access_token='31271710-9LLAFiGhbMz6913cXzO2pnEMI3Rx2sIGdg13mZexV'
        self.access_token_secret='KKjfmCapFdI4yxgOzn65HGmwo7QUlnJEn34M4EjgiTamJ'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_33():
    def __init__(self):
        self.consumer_key ='g4JfjXg8NqITmzo1NGo4QXbRj'
        self.consumer_secret='je2tRAOCe5Aa7ebPYZ5HysogV0cpbdqKpvACBY8zyxPzSjos45'
        self.access_token='31271710-6JvlWaunEh5ULtdZCPWOXswi0Uqe8J2gh46NANv5Z'
        self.access_token_secret='QayLKn648SMpBpKuZPSPql5DFEPtMtrylN64xmSGk5jlu'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_34():
    def __init__(self):
        self.consumer_key ='bF517AHO4argSSGkYO2telCFX'
        self.consumer_secret='kZCErQPCfL2CDK8jm0weB3apF5zYtjxACKyJhDfwdg3b4nTRfo'
        self.access_token='1952939204-8vq8imAFkVtSZdMgD6hZpAx6QIfpoJDQi6ekqvO'
        self.access_token_secret='jM4fMB96uQnvGoxEISvX5ddSAXpSahzPR3MbMaI8kHWF2'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_35():
    def __init__(self):
        self.consumer_key ='VutUaqor6AE74skI1Th3BZmIr'
        self.consumer_secret='AeLmdcNBjuUA3oKecyLBm1bZmLQERZtUUBFeHBSMK7TpLqekc4'
        self.access_token='31271710-sbdn0eVYXlPcGFbA7G0AF5IGOU0W1klm3jXW8a9sO'
        self.access_token_secret='Cx3dvsiS4x233Fz5cebsmULLxdNfLS0mWX5k6PMCiP13P'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_36():
    def __init__(self):
        self.consumer_key ='PE5RWF3d4QK3GClzwnR7ilUSr'
        self.consumer_secret='stxyKj9VV1XhImzmJIkC18ISdRyyRAwqlFEEkzxdghcX22Orfk'
        self.access_token='31271710-IZyq465YSJg4W4GHjDRWovNK7WnI4ccrElTYJgJdR'
        self.access_token_secret='eiC1V9kOA54UlRp2WJgresXkl7oVdfcn1icW3Aq7LO2fk'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_37():
    def __init__(self):
        self.consumer_key ='zyM5D5cpbnnbsKV2tPlG6nl1k'
        self.consumer_secret='9eKFf3aytGua5KPZtxBHJUQVDHpIKM85pVUdgkudTk8E4URcRn'
        self.access_token='31271710-iygEsocC8jJCOQ9Q6tWxdBXHz6nQl70Dfu7dG7bl3'
        self.access_token_secret='bl6qHv70Eva7KTK3XUEe46uuVUFQ3mlPykW34mtiXetX1'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_38():
    def __init__(self):
        self.consumer_key ='1MoUSFqTUlTlJl15YTSBTKv5W'
        self.consumer_secret='hT1QqySa8IV4SbgPjpDz4p5Afwsep4yyZaWIjV74TkBPq6cytI'
        self.access_token='1952939204-zPwRfIgArUVnJrAUeYRXuYNcgFDlYKqsHzJDI6N'
        self.access_token_secret='Rd0MLlsVAIoOtxixUpq4AvYdDAb4mR1k39chUT1FMqr2c'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_39():
    def __init__(self):
        self.consumer_key ='QlzXOglosLTGNtS9QdhC0kXoj'
        self.consumer_secret='89yKIDFcFQmJ3OmL1YDr4I3vNHlMIaGlzMa4xKrPkHYJYKNe2m'
        self.access_token='1952939204-qIB4j7br8HQcWm191Bj7xn59o4SMvTULAOHVCK8'
        self.access_token_secret='nYPOBm5fVZl1MDpa09NiqKEChBRGN6IMqZMOvDPGay77I'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_40():
    def __init__(self):
        self.consumer_key ='bFGop3IRKqwEPCGXAbJKy71gT'
        self.consumer_secret='k4Z0P93YnAU5dWn7EKUF0EsN3BV0ivFMlVRrbd2p8jxj5tJcEo'
        self.access_token='1952939204-lKBRyI8W9ggryfgvovOQCwWvb27GUPoelBFqHGB'
        self.access_token_secret='P3Q8jsg4bSWLK7GxOpqYCJZwkb5Tz8I8SJT9wgBHtR6gW'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_41():
    def __init__(self):
        self.consumer_key ='psDacnfmy6lCpaDclpfyFH9ZQ'
        self.consumer_secret='vVrFjz6FDQ1nRrN1tyVnXYeU7qszTTUCZz4il9ZFMppPi0tb18'
        self.access_token='31271710-ORxh2Zf99LpEJ3ujzZGsbeZ5VhaDh9dMagNzD0QVO'
        self.access_token_secret='9LZf1uHhwFizXTIRYmBngasAiqBD1xJRQrcVBwvtzrWyq'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_42():
    def __init__(self):
        self.consumer_key ='xQdIjL5aqwJvF7YX0YZCMc6aI'
        self.consumer_secret='AmtMvpUiV6F6zd3NoP2VoiQit1cdbUQl66awISaJULLjGiWPmq'
        self.access_token='31271710-zSvklwDpOvDEFMmcSmJXFn5rdYEJ3PmU2g6JOSFKG'
        self.access_token_secret='wHD7A4xpbcKEs2TCwdL7y0lf2SGrK9k5pdlsDXN9ouUL7'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_43():
    def __init__(self):
        self.consumer_key ='TwCUNY7EWG3ohamN7uEF4FpiP'
        self.consumer_secret='0INMSiGtDTOsBRmoQu4X2yzjW4hr9Ew5qpV9CAnlPzSBZ6dgj1'
        self.access_token='31271710-cmdu5nxFiXjxboHMb3lWXeHzNIdSMv5wgvLXa8QVz'
        self.access_token_secret='sPeNBkiJHqDLKDURaNk8Kwver90x7sDD0FuQgfPidUHoQ'

    def getconsumer_key(self):
        return self.consumer_key
    def getconsumer_secret(self):
        return self.consumer_secret
    def getaccess_token(self):
        return self.access_token
    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_44():
    def __init__(self):
        self.consumer_key = 'aWJh9iIzIups2owIRNyNO5Xgv'
        self.consumer_secret = 'jHTHxOTC7WBU2fPazx4BA0tk04FCBY4FyRYhfMTjs8F2UrIins'
        self.access_token = '22767625-TXvaqR81HQaKcDPjmhDcEaaGu3JzOdsOE1nhaPHg1'
        self.access_token_secret = 'GeKYbPaU5tdndLILhTt2VlWpc1GY2pVFNezu7kgLSUAUA'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_45():
    def __init__(self):
        self.consumer_key = '0puNrIR8wS0JqreR3YFPEnCai'
        self.consumer_secret = 'cLCweaMX5b8vvDPCXspD7xl4qHJ7TnPR5e0ZGia6i6IK2EOnNe'
        self.access_token = '22767625-2HHoukim8cljMLnxzz132Jc2GbPE7Iao7AFzmfHHZ'
        self.access_token_secret = '4vQqnY6Fp5ARM0oYTlRPblWivxA7mIV0TyXole5UAYjFG'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_46():
    def __init__(self):
        self.consumer_key = '42W6m12pCRBdLVYGbVK5S41Ki'
        self.consumer_secret = 'fSs48AIn6qWmMFFFy8sqAnsLVSUAMRuXiu5cHWKAKVJnDQ3fzD'
        self.access_token = '22767625-jRbIzkeGwxDTlwBCNPLsAqtpq0p0SHJBASw7PZAe6'
        self.access_token_secret = 'ZHOHemvIscjJ4jK1DlVoNArnisQxJq7STI5PmSQQaPEb9'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_47():
    def __init__(self):
        self.consumer_key = 'eGtBrRBI6XkdGw0nRXnOKFagH'
        self.consumer_secret = 'jz9eDCOQlQwU5hfSAIuSxsT7Qsf1HQOL9isas0CVjBdAV46Vub'
        self.access_token = '1952939204-O5bBvYKco4IgJ62AAgVUMx9kKRSMQkdftgn8uyF'
        self.access_token_secret = 'NahZnFRKGA4xjqmgdohIoWiKDrgV6C0WZZayKvUg4Y3Lt'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_48():
    def __init__(self):
        self.consumer_key = 'Pw9CvV3E3mjNM1TllNvKaT7Il'
        self.consumer_secret = 'HLOjJVdQNR0UunMjEl4Rom4A5uTP8oN6q8k0eueYbZMpAypB9l'
        self.access_token = '1952939204-YOgoygjojHUa33FSsagWQmHi6k4BULcruXaQbJF'
        self.access_token_secret = 'PhTlFJBYAxAo6Kzb30Eqj8QEoTjWZwb9LSQ7fbCtmly2i'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_49():
    def __init__(self):
        self.consumer_key = 'AKIVAmaDnYXU77GpcnI3BI2sa'
        self.consumer_secret = 'tO7xLxOdwjd5pSGXLzKK8wiC1a2r8uXCynGeRwq9KMPNY7MjOd'
        self.access_token = '1952939204-2rZhTIKGAPAzKM8SPwI8yDNCT15mGvw4uDHSyU8'
        self.access_token_secret = '3p9K1cpK4j4tWIU6aq8sCYtohjoF6s5Pjer1w8dGYEPLW'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_50():
    def __init__(self):
        self.consumer_key = '7Mw3IByaX5aROgRYTlLh11yly'
        self.consumer_secret = 'ss3KgDEGNRFHm4LE2pSJV9zVZr4cCMh1SAh9bfD4fJITWQB1wh'
        self.access_token = '1952939204-9V7fyOTqBF775yIh3aEp49RLmkLWcHnGqojbAqY'
        self.access_token_secret = '8Djy02saK0eRqBhTYNCkNky4aKi3LJli4vhcwPoKaGKth'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_51():
    def __init__(self):
        self.consumer_key = 'WqKx4pEJVrcyKGyqa1dsY8IPY'
        self.consumer_secret = 'iR8a2GWW4JjPAxrISFTXeApwkNxpbffjm3A132p6DpmabYHTKR'
        self.access_token = '1952939204-yalsAbDfvnBlXSVgMhIijzpFqeBhhOiry853UZA'
        self.access_token_secret = 'vFc7PuClYt4ugcjENgp6nth8ptMBmFgojA6AU0W6PAaVU'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_52():
    def __init__(self):
        self.consumer_key = 'UOsP4ywgJ8flVDXPnqzcUHxPh'
        self.consumer_secret = 'xSG63rvNPl3Y3IUamshq2BbCKyU41tILB4rOLSIDMLSez8Xxc2'
        self.access_token = '1952939204-v55vvLKnWIeY9hleNhjj4n4IYyuyG88bsrjCmkt'
        self.access_token_secret = 'DSzcuQVrTS0tX1fZ7V2HsrvWCDm1ipGnwrkpObXNFT2dt'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_53():
    def __init__(self):
        self.consumer_key = 'kmCGq18QvEXkCuItGlxNMHOvy'
        self.consumer_secret = 'yOhFjsmW5VKNdvOEM1utzDF4KLWKMZr5UjkMKe7blhAhPAjjic'
        self.access_token = '1952939204-Vbrvk7bmzSJ3WsgjgFFS3hVxltFUX2mvgAtqzR2'
        self.access_token_secret = 'fpPKksaL7beAKfalBEwzE3bEcA4mVSHYcsXudt9Qmmjsu'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_54():
    def __init__(self):
        self.consumer_key = 'l5tRo4zWErqQdRFCWAjrHv7BK'
        self.consumer_secret = 'G8rykHwc6Cf4wv2esUvONjR8e67sZ72KXWJumwrrC2gWdV7mmB'
        self.access_token = '1952939204-CwQ4xABH4XhhCiISZkTjoeGedOgEH3jsGdDFdn5'
        self.access_token_secret = 'fVPKQ25xpIkOIdCwfpYpEsKpQE2kZFiXUa5TrlcNWIisD'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_55():
    def __init__(self):
        self.consumer_key = 'zoCKgPnJb4gQv4yziu03xFcES'
        self.consumer_secret = 'h6Ha18WyR8X5rY90dQfmLgCWcScpEIckbOZOHLy4M0drnpek6p'
        self.access_token = '1952939204-rVjUqp1uFrZQGvbLGEf3GFzfM5KmhZVbsgHU3R2'
        self.access_token_secret = 'DViB4oIhSKIusj2jtftSbaYRSpBZoiRf7H44yKRoG48h1'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_56():
    def __init__(self):
        self.consumer_key = 'NBzfVKV6vEIBWKxk2amP6izmX'
        self.consumer_secret = 'cCOJmRUkMR0WCCYi5Kbo4z0tfZ0r80DBikH6hS7pvli6FULXeh'
        self.access_token = '31271710-qJr3nhPY4fLUAWq3tGMFHeIjwRGbKle8KV7RbBExl'
        self.access_token_secret = 'fAgoSgJZjB8su20eRwo1YqSGHjTikKQE0nQGZvyhzIi4O'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_57():
    def __init__(self):
        self.consumer_key = 'dxJkLoXVAgvcVSXN2B5ZnalPH'
        self.consumer_secret = 'OfofwCm4yH6kyaSspvTGEKU8Q4xjz8HuLXhYkRRJlZOLYCQ56L'
        self.access_token = '31271710-XTyjElsKjoIebeKOcr0OIAwpC4nHlVkVwFZpsahY3'
        self.access_token_secret = 'f6sxRRHLcAp0leVHjZVMWRc4FZtdK5iLGfREkCZRfd6gT'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


class authentication_58():
    def __init__(self):
        self.consumer_key = 'B81k8RGOMmod5GMkWr59TQ58k'
        self.consumer_secret = '01aNZO74q69pRgMO8kwWLiDNJYu84gDtEpl22W7qYAcc73DupH'
        self.access_token = '31271710-00Zzs0j6dbHM5cx53WEOzOuJiryeuWBTMhihvzfP1'
        self.access_token_secret = 'gv20u3UZcrxtrt0cqfWD4gGC3ckyaSKqJThUtWe6r05It'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_59():
    def __init__(self):
        self.consumer_key = 'vB6Pod10otTlWqhZR7wuhv3mf'
        self.consumer_secret = 'U613duxSGL3ww1qi83hB3LgNh9niYlWJL5YyRrZhXdGdCpo7lT'
        self.access_token = '1952939204-tonPUN9CfvrLLEvYWIXN6WtSSaSOCAwcSMMTkj2'
        self.access_token_secret = 'WBuTE7lyaA3j3mDWDT3ffPle1uXdTSpEe7oQsm7cFizuU'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_60():
    def __init__(self):
        self.consumer_key = '5mZ5kJQ3bLaztvEGDklBR6q5C'
        self.consumer_secret = 'dgtjt6aW58YWoxruCAWq0iDa8jnPUc1lCKZ4Mtq7dQwVD7731Y'
        self.access_token = '1952939204-boBaVcdSXa71BkBqdxtGiyERMiTPAEB5nhoyJFR'
        self.access_token_secret = 'CvOXfnX2jJW1Bl7dciqt5Ov5alSUjdBURkjr9kJWcJgFu'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_61():
    def __init__(self):
        self.consumer_key = 'lUTmOWdSLOoJQAGhVMYBBnIts'
        self.consumer_secret = 'NJNSrB1OZ7Q5MEXA6R59ZwEOkFl89PkUpPeMfPVs849NbSJyyM'
        self.access_token = '1952939204-5DQmrNb8o5lx2dYOdY4jUXDLheLMAUYYYazI2S7'
        self.access_token_secret = 'brC2PR5CwMe5rXTau3UoWTdvTtbGMN1AwccLgCHb8Pdg2'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_62():
    def __init__(self):
        self.consumer_key = 'iXVEN2om0kZdlSVimv7BhJfIu'
        self.consumer_secret = 'tVNqNw52xnCFCFdAbLrrcGRSvdp4ljPtMziQT5I3PJvEuCv7Zj'
        self.access_token = '31271710-WnmGLCoj9iEdvIupe9WHIjDIoLyoXgqxCaxuOVPgf'
        self.access_token_secret = '3nS3jJrCQkLtpt0slrkVa7J6VOVLfmA0AczSJsZ0UkyJ8'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_63():
    def __init__(self):
        self.consumer_key = 'tlluhNrxSZ70TqGDvQuSFRbGx'
        self.consumer_secret = 'z6yNFmUMp9VD8RP1oYpmROcUlq940NQTv4sjMUYntPy7USiuUL'
        self.access_token = '31271710-KprAGRzKwDXuSn4TE0wBjpojKbpg9gTZOJmFxCBJV'
        self.access_token_secret = 'Momuu9dVOD5LeYTfDxatxvLoey1qMXuzgGcp7dUlpIHHQ'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_64():
    def __init__(self):
        self.consumer_key = 'g6ciSBmeOQokRyaNOwbslmqsq'
        self.consumer_secret = 'xEUgsJVAt7WqH5LMErDVwsbtlBfqgfYM8Xn3W0Kqp5lMDRAHH2'
        self.access_token = '31271710-QVSHKG44Q5RlQjHxVKFBbotFo3m1lUZORz33zBo8l'
        self.access_token_secret = 'U1CGOq9t2WLCfCd6qpXK11OThODqLqBdrBt16Nka3fpt9'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_65():
    def __init__(self):
        self.consumer_key = 'T3KiSw9ytUc8mo4pFyg6bmsAO'
        self.consumer_secret = 'e37KsYwH54QK5GRWuNkXUMQ8qXS83rHE1BO6VsMWwRvR33tsIE'
        self.access_token = '886185045731442688-n3cbEfLcQyrC6KhA1dz3H8iFN0jpelh'
        self.access_token_secret = 'jaIMV38HQJNQZnkePjYdco99W8MSh8DfapvNvka3cncke'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_66():
    def __init__(self):
        self.consumer_key = 'lb6BiALVuGfSvtxv9i9OzJzEI'
        self.consumer_secret = 'vEqa5bANHHIc3yJD14OfydeP5OVM0wu3yQtJrhK4TNn8e8X8c4'
        self.access_token = '886185045731442688-9qbvnO3L8cASURo9Qj0eaSlNNCKC8gQ'
        self.access_token_secret = 'KzZsqhRrLmGmaRC1THU3VscYLc6uK6U0B5XY57AJ0Bnpm'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_67():
    def __init__(self):
        self.consumer_key = '4XZzY03ZUj0cB1uAefCiQmdnI'
        self.consumer_secret = 'kslhmAdt91PmCIzVQxi0FB02GUwn1eyZRObDS0n7JLqzFwGqnn'
        self.access_token = '886185045731442688-8lJxendxaPixx3kUFfekM5iHcWyzPfy'
        self.access_token_secret = 'JwKh1OP4yE821an2RuSOo7gqnO8AD6QdsMpukiASWnvNe'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_68():
    def __init__(self):
        self.consumer_key = 'H1BRwq7ZH5F636cxslMVolUJH'
        self.consumer_secret = 'tRiuXF7QgGC9tnOWChmiKdwDA6QgwEKRXE0wv9PQlK7Tn6ZRMu'
        self.access_token = '22767625-k0JGvcA9dq81y1782WLqtCRBLetvK9wzfYnJmS8Fx'
        self.access_token_secret = 'DtK5ESV6PU300CckesDpvSQd9FGnmApJZB3kC0TCjcEXe'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_69():
    def __init__(self):
        self.consumer_key = 'eWp14UoSMNpNOa2itiUzwEpFL'
        self.consumer_secret = 'wGEiyNel9QoU1Q6KhM10TrpxISkH5kufCKU09utFBBwnfn31jX'
        self.access_token = '22767625-qyWPGU2GxAhoqtXsYdvJC3RLGRXwkBP0256zmzsjH'
        self.access_token_secret = 'u3PSkyfwdNbOnHCAEZAP0FzJoaO39VoV3B7NGou7B2t9y'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_70():
    def __init__(self):
        self.consumer_key = 'G7rCYJlG6dKPj4ueiePJoeMj1'
        self.consumer_secret = 'b9uGouGLUaeXxKwZbWlsCDaORPbswBm6U6NlzLyWgbYwddrTAH'
        self.access_token = '22767625-6aaan90HxVdqpcK99TwZYRPsyzMUW1fQdqZ3yWNse'
        self.access_token_secret = 'yWnvhRhbC0WtVYvclZ5QsOMxVHSdCE3UBzHPve8TqVFyc'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_71():
    def __init__(self):
        self.consumer_key = 'Q6Ld6oylvOatzmx707cuuX4uy'
        self.consumer_secret = 'SbVCD03u4qGQMlDybVQTUDJxZxEEodigIAU8QmWRWzCAu5NEHd'
        self.access_token = '1952939204-r1COLGG0RDxbTFHwGCvpjy9nMlmiyDvxpOw0SNk'
        self.access_token_secret = 'GWVcCGEEOhyt3O55gsl1e4dQ3I4lbqkK8TdCBLEGemPow'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_72():
    def __init__(self):
        self.consumer_key = 'h42ATFAqSveUskEVM0HIdQy0J'
        self.consumer_secret = 'XSiidtjGcegjNue9a5pD1YkYSmIpUSF4HUxsuXu87fmT5BQuo6'
        self.access_token = '1952939204-AGmDB2rLPFxuzTkTGhVL484KzTvtdz5uZtkLu2p'
        self.access_token_secret = 'hBLLBtfagilSI9MZa0rAiEk0089LsflIrwgNUekZL65SI'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_73():
    def __init__(self):
        self.consumer_key = 'S5S1JUm1iTb92mR2KLtv5Zbvq'
        self.consumer_secret = 'FImVixCl5pyjSStXo8WacfPIaUS3WeETgVnJRUrjv8OsL1MicN'
        self.access_token = '1952939204-HmJvLm2WqCZE1qjRIX8GAaDwVq5rAAV3PyIeYqr'
        self.access_token_secret = '7RP97JE81R4MD5LudpcydxC7krEWlBi9ybNzsl8OQp2Ct'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_74():
    def __init__(self):
        self.consumer_key = 'TzcomWl0LZVA95KwK5YQafZWl'
        self.consumer_secret = 'DilEIZFBXjBNAiiVXqDyrMPJUylk9sGnIQAeJpaUXCk7aQc6kc'
        self.access_token = '886185045731442688-iO4GFCgSzAqvg3mcRFpAr8QOSxEHPEg'
        self.access_token_secret = 'qttnTkbJxcNVkVgHjNHgVa3jiC8n1CuDXGGk9u6GE8BFE'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_75():
    def __init__(self):
        self.consumer_key = 'PSvtMPJO85bDog3HjVVoquGa1'
        self.consumer_secret = 'Q3F9lmj0BqopYFt8tlql3PQ55iYRqV3OcbbHuZtewCccqEPptH'
        self.access_token = '886185045731442688-H37LluaKt1ISXMRvgrwB5ig6YgKGe60'
        self.access_token_secret = '9q6HyPEz89zx47W3AYxCv1WtVW76Wwqizfe4NQcGGRCFo'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_76():
    def __init__(self):
        self.consumer_key = 'PozCQxmaOGgShYPjTqzNAmGoY'
        self.consumer_secret = 'KX8ojgrmIVqUyYYkgiccuTOfeZkYBSrWLuwUQCgrAijRo7kCMB'
        self.access_token = '886185045731442688-BUuS1aqMp3r98tqVbQW8dSlPhd2NxcH'
        self.access_token_secret = 'wVbQGLRw2efKCQM1R0C2WqphT7dlVxffVB4pC3hqmr9pB'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_77():
    def __init__(self):
        self.consumer_key = '2f3k68HspgmUwi8MlmtqyH9Up'
        self.consumer_secret = 'Xf8oWCIMvbxMUOwdhg1El5hbC5NIjy3p5sfldKLy4VqMR3gzea'
        self.access_token = '31271710-inr5sAZeqmiiVsJm1OVYAHhTafEbhYeULPqIbqhw0'
        self.access_token_secret = 'vTJFCVFgo9Lkbi0E5IGwtq3JxjymFSPC37REbNh9V9caQ'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_78():
    def __init__(self):
        self.consumer_key = 'kYBaNY9y1AmjFqrBLM49lxqOn'
        self.consumer_secret = 'YlVG30ObUyVZWrPjHMtxdvQx4uEA8lNZg69YmMsz80GXVFR2bB'
        self.access_token = '31271710-WpvToojqApgLgUNh5drglYM9xAl7TNQoFDIHaXQlq'
        self.access_token_secret = 'fQ5uedQJPM6aToom1FCwWD1gL1oTqgGV5Wfnnw4xmVGzt'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_79():
    def __init__(self):
        self.consumer_key = 'mKS5E3MQ7DhJoFvP2xVCFbWs0'
        self.consumer_secret = 'OXQjqKT5MyPjUhcmhsMC0G7TyVLTPfMwRHNgfYCA8gDFXVTK2r'
        self.access_token = '31271710-qis0Yayi9LaAPOYhxgp3g6PMGzy6MHlXu4CpCrC2G'
        self.access_token_secret = 'mSx9v4GUyxlyNc7Y1h0Ldt3DW3Hnw52ZEJOCSWX2f8Vbl'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_80():
    def __init__(self):
        self.consumer_key = 'j9GQ5wkSluaH7EAzxYRmG2ZlC'
        self.consumer_secret = 'R669gPiaGMWBYDPcsuGt7LjYaqExuNqIdKF8R3O5lgTpRaaHQK'
        self.access_token = '22767625-3A0IV8mleELQ4CbvEevIPrhHWWamA82lj5lXPg2qd'
        self.access_token_secret = 'sMc8HY02DfRrbMHH4da8xMr2fppnrpDPso3ExtGLdcUF5'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_81():
    def __init__(self):
        self.consumer_key = 'eTVYp9ZcGfpeeSMa9xnAf1aTE'
        self.consumer_secret = 'vzwnanbwmYQkFLJfaWN2bjalnhGfcshSTy1rGKOjjmJRpFcvgw'
        self.access_token = '22767625-lsJ5KfU99ub5hTpKBUIcCrs2TC3JjTkfpQOVC53iA'
        self.access_token_secret = 'Gc8B44osY5ltWhU9ZNXAveo8Yh1L3jKedl3pXQjOzoNAk'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret

class authentication_82():
    def __init__(self):
        self.consumer_key = '9FkOyBVHi0yX4h9pJq1dL1Dqp'
        self.consumer_secret = 'ztXYYzbjO5Dw7yrQWDbOE9v1i0zjnqzRmxsAGs15rbq0eIr8up'
        self.access_token = '22767625-Zv7kwMW2KVbTHXjBPekEfbBJibVdcNCIqEoiu7N5V'
        self.access_token_secret = 'nZSsPGesefv8GOgSUX80AsWh4KT7r4Y4RoanOsbWpVeXg'

    def getconsumer_key(self):
        return self.consumer_key

    def getconsumer_secret(self):
        return self.consumer_secret

    def getaccess_token(self):
        return self.access_token

    def getaccess_token_secret(self):
        return self.access_token_secret


