"""
Holds methods to process raw tweet documents from API
Author: Josemar Caetano
Date: 04/24/17
"""

import os
import sys
from datetime import datetime

import json


class tweetMethods:
    def __init__(self):
        pass

    """
    Function that creates the twitter collections document
    """
    def createTweetDocument(r_tweet, fromStreaming=False, originalTweet=False):
        document = {}
        tweet = {}
        user = {}

        try:
            if (fromStreaming is True):
                if(originalTweet is False):
                    #print("From stream tweet: ", r_tweet, flush=True)
                    raw_tweet = r_tweet._json
                    raw_user = r_tweet.user._json
                else:
                    #print("From stream original tweet: ", r_tweet, flush=True)
                    raw_tweet = r_tweet
                    raw_user = raw_tweet['user']

                # Extract the relevant information from tweet.user
                user = tweetMethods.createUserDocumentForTweetCollections(raw_user=raw_user,
                                                                          fromStreaming=True)

                # Extract the relevant information from tweet
                tweet['text'] = raw_tweet['text']
                tweet['coordinates'] = raw_tweet['coordinates']
                created_at = str(raw_tweet['created_at']).split(" ")[1] + " " + \
                             str(raw_tweet['created_at']).split(" ")[2] + " " + \
                             str(raw_tweet['created_at']).split(" ")[3] + " " + \
                             str(raw_tweet['created_at']).split(" ")[5]
                created_at = datetime.strptime(created_at, '%b %d %H:%M:%S %Y')
                tweet['created_at'] = created_at

                if 'retweeted_status' in raw_tweet:
                    tweet['retweet'] = True
                    tweet['original_tweet'] = tweetMethods.createTweetDocument(raw_tweet['retweeted_status'],
                                                                               fromStreaming=True, originalTweet=True)
                else:
                    tweet['retweet'] = False

                tweet['source'] = raw_tweet['source']

                # Logical set
                document['_id'] = int(raw_tweet['id'])
              
            else:
                if (originalTweet is False):
                    #print("Normal API tweet: ", r_tweet, flush=True)
                    raw_tweet = r_tweet._json
                    raw_user = raw_tweet['user']
                else:
                    #print("Normal API original tweet: ", r_tweet, flush=True)
                    raw_tweet = r_tweet
                    raw_user = raw_tweet['user']

                # Extract the relevant information from tweet.user
                user = tweetMethods.createUserDocumentForTweetCollections(raw_user=raw_user,
                                                                          fromStreaming=False)

                # Extract the relevant information from tweet
                tweet['text'] = raw_tweet['text']
                tweet['coordinates'] = raw_tweet['coordinates']
                created_at = raw_tweet['created_at']
                #print("Created at: ", created_at, flush=True)
                #created_at = datetime.strptime(created_at, '%b %d %H:%M:%S %Y')
                tweet['created_at'] = created_at

                if 'retweeted_status' in raw_tweet:
                    tweet['retweet'] = True
                    tweet['original_tweet'] = tweetMethods.createTweetDocument(raw_tweet['retweeted_status'],
                                                                               fromStreaming=False, originalTweet=True)
                else:
                    tweet['retweet'] = False

                tweet['source'] = raw_tweet['source']

                # Logical set
                document['_id'] = int(raw_tweet['id'])

            document['tweet'] = tweet
            document['tweet']['user'] = user
    
            return (document)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                  datetime.now(), flush=True)
            

          
    """
    Function that defines user specifications for the tweett collections
    """
    def createUserDocumentForTweetCollections(raw_user, fromStreaming=False):
        try:
            user = {}

            user['id'] = raw_user['id_str']
            user['name'] = raw_user['name']
            user['username'] = raw_user['screen_name']
            user['created_at'] = tweetMethods.getFormatedDate(old_created_at=raw_user['created_at'], fromStreaming=fromStreaming)
            user['description'] = raw_user['description']
            user['geo_enabled'] = raw_user['geo_enabled']
            user['verified'] = raw_user['verified']
            user['lang'] = raw_user['lang']
            user['protected'] = raw_user['protected']
            user['statuses_count'] = raw_user['statuses_count']
            user['followers_count'] = raw_user['followers_count']
            user['friends_count'] = raw_user['friends_count']
            user['favourites_count'] = raw_user['favourites_count']
            user['profile_image_url'] = raw_user['profile_image_url_https'].replace("_normal", "")
            user['protected'] = raw_user['protected']
            user['listed_count'] = raw_user['listed_count']

            return (user)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                  datetime.now(), flush=True)

    """
    Function to get twitter parameters
    """
    def getNewAttributesFromRawTweet(r_tweet):
        document = {}

        try:
            raw_tweet = r_tweet._json
            raw_user = r_tweet.user._json

            tweet = {}
            user = {}

            # Extract the relevant information from tweet.user
            user['profile_image_url'] = raw_user['profile_image_url_https'].replace("_normal", "")
            user['protected'] = raw_user['protected']
            user['listed_count'] = raw_user['listed_count']

            # try:
            #     soup = BeautifulSoup(raw_tweet['source'], "html.parser")
            #     page = soup.find('a').getText()
            # except Exception as e:
            #     page = ""

            tweet['source'] = raw_tweet['source']

            # Logical set
            document['tweet'] = tweet
            document['tweet']['user'] = user

            return (document)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                  datetime.now(), flush=True)

    """
    Function that extracts important user information
    """
    def createFollowerDocument(raw_user, followedName):
        user = {}
        try:
            # Extract the relevant information from user.user
            user['username'] = getattr(raw_user, 'screen_name')
            user['following'] = followedName
            user['timeline_collected'] = False
            user['valid_user'] = True

            return (user)


        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                  datetime.now(), flush=True)

    """
    Function that extracts important user information
    """
    def createRelationshipDocument(follower, followed):
        user = {}
        try:
            # Extract the relevant information from user.user
            user['_id'] = str(follower)+","+str(followed)
            user['follower'] = str(follower)
            user['followed'] = str(followed)

            return (user)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                  datetime.now(), flush=True)

    def createUserDocument(username, hop, timelineCollected):
        user={}
        try:
            user['_id'] = str(username)
            user['valid_user'] = True
            user['timeline_collected'] = timelineCollected
            user['friends_collected'] = False
            user['followers_collected'] = False
            user['hop'] = hop

            return(user)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('\nError: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, '\tDatetime: ',
                  datetime.now(), flush=True)

    """
    Function to format the date
    """
    def getFormatedDate(old_created_at, fromStreaming):
        try:
            if(fromStreaming is True):
                created_at_splited = str(old_created_at).split(" ")
                new_created_at = created_at_splited[1] + " " + \
                                 created_at_splited[2] + " " + \
                                 created_at_splited[3] + " " + \
                                 created_at_splited[5]
                new_created_at = datetime.strptime(new_created_at, '%b %d %H:%M:%S %Y')

            else:
                new_created_at = old_created_at
                import dateutil.parser
                new_created_at = dateutil.parser.parse(new_created_at)



            return (new_created_at)

        except Exception as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print('Error: ', e, '\tDetails: ', exc_type, fname, exc_tb.tb_lineno, flush=True)
            print("\tError created_at: ", old_created_at, flush=True)

