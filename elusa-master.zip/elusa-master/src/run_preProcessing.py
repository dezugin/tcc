import sys


def main():
    from pre_processing.pre_processing import preProcessing


    from pymongo import MongoClient

    # MongoDB connection
    client = MongoClient('mongodb://localhost:27017/')
    # client = MongoClient('mongodb://leasdle01.icei.pucminas.br:27017/')
    client.france_election.authenticate('josemar', 'pucmg$elusa$2016')
    print('Connected to MongoDB!', flush=True)
    db = client.elusa
    print('Connected to elusa DB!', flush=True)



    from datetime import datetime

    start_time = datetime.now()

    preProcessing.buildTimelinesSampledCollection(db=db)

    end_time = datetime.now()
    print("\nStart time: %s\nFinal time: %s\nTime elapsed (seconds): %s\n" % (
        start_time, end_time, (end_time - start_time).seconds))


if __name__ == '__main__':
    main()
