from tkinter import *

class interface:

    def __init__(self, toplevel):
        self.fr1 = Frame(toplevel)
        self.fr1.pack()

        self.titulo = Label(self.fr1, text= 'Variação de humor dos tweets', font=('Arial', '14', 'bold'))
        self.titulo.pack()

        self.btUSA = Button(self.fr1, text=" Eleição USA")
        self.btUSA['font'] = ('Arial', '12', 'bold')
        self.btUSA['height']= 4
        self.btUSA['width'] = 15
        self.btUSA.pack()

        self.btFrance = Button(self.fr1, text=" Eleição Francesa")
        self.btFrance['font'] = ('Arial', '12', 'bold')
        self.btFrance['height'] = 4
        self.btFrance['width'] = 15
        self.btFrance.pack()

raiz = Tk()
interface(raiz)
raiz.mainloop()